/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/js/main.js":
/*!************************!*\
  !*** ./src/js/main.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _styles_style_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../styles/style.scss */ "./src/styles/style.scss");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_Lib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/Lib */ "./src/js/modules/Lib.js");
 //----- Библиотеки js -----//


__webpack_require__.g.jQuery = (jquery__WEBPACK_IMPORTED_MODULE_1___default());
__webpack_require__.g.$ = (jquery__WEBPACK_IMPORTED_MODULE_1___default()); //----- Основной js -----//


(0,_modules_Lib__WEBPACK_IMPORTED_MODULE_2__.Lib)();

/***/ }),

/***/ "./src/js/modules/Lib.js":
/*!*******************************!*\
  !*** ./src/js/modules/Lib.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lib": () => (/* binding */ Lib)
/* harmony export */ });
var re = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
var re1 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{5,20}$/;
var currentEmail = "email@gmail.com";
var currentPrice = 0;
function Lib() {
  function controlDropwdown() {
    var selectedList = document.querySelectorAll("[data-form-dropdown-selected]");
    selectedList.forEach(function (selected) {
      var dropdown = selected.closest("[data-form-dropdown]");
      var optionsContainer = dropdown.querySelector("[data-form-dropdown-container]");
      var formSelectedWrapper = dropdown.querySelector("[data-form-wrapper]");
      var optionsList = dropdown.querySelectorAll("[data-form-dropdown-option]");
      var selectedIndex = -1;
      optionsList.forEach(function (option, index) {
        option.addEventListener("click", function () {
          selectedIndex = index;
          console.log(option.querySelector("label").innerHTML);
          selected.innerHTML = option.querySelector("label").innerHTML;
          optionsContainer.classList.remove("active");
          formSelectedWrapper.classList.remove("active");
          selected.classList.add("active");
        });
      });
      selected.addEventListener("click", function () {
        optionsContainer.classList.toggle("active");
        formSelectedWrapper.classList.toggle("active");
        selected.classList.remove("active");
      });
      window.addEventListener("click", function (e) {
        var path = e.path || e.composedPath && e.composedPath();
        if (path.includes(selected)) return;

        if (optionsContainer.classList.contains("active")) {
          optionsContainer.classList.remove("active");
        }

        if (formSelectedWrapper.classList.contains("active")) {
          formSelectedWrapper.classList.remove("active");
        }

        if (selectedIndex !== -1) {
          selected.classList.add("active");
        }
      });
    });
  }

  function validForm(form, funcSend) {
    let isAllValid = true;
    const submitBtn = form.querySelector(".pop-up-cart__form-btn");
    const inputsAuth = form.querySelectorAll('.pop-up-auth__field');
    const inputCheckbox = form.querySelector(".pop-up-auth__checkbox .custom-check");
    inputsAuth.forEach(function (el) {
      const input = el.querySelector('.pop-up-auth__input');

      if (input) {
        let isInvalid = checkInputOfAuthForm(input);

        if (isInvalid) {
          el.classList.add('invalid');
          isAllValid = false;
        } else el.classList.remove('invalid');
      }
    });
    if (inputCheckbox) if (!inputCheckbox.checked) isAllValid = false;
    if (!isAllValid) submitBtn.setAttribute("disabled", "disabled");else {
      // запрос на сервер: вход/регистрация
      funcSend();
    }
  }

  function checkInputs() {
    const input = document.querySelector('.profile-info__input[valid]');
    const form = document.querySelector('.profile-info__form');
    const formLogIn = document.querySelector('#popupauth .pop-up__auth-form');
    const formSignIn = document.querySelector('#popupsignin .pop-up__auth-form');
    const inputsAuth = document.querySelectorAll('.pop-up-auth__field');
    const inputWrapper = document.querySelector('.profile-info__form>div');
    const btnEditChanged = document.querySelector('.profile-info__btn-edit-email');
    const btnEdit = document.querySelector('.profile-edit__btn-change-email');
    const edit = document.querySelector('.profile-info__edit');

    if (input && form && inputWrapper && btnEditChanged && btnEdit && edit) {
      input.addEventListener("input", function (e) {
        if (e.target.value) {
          btnEditChanged.removeAttribute("disabled");
        } else {
          btnEditChanged.setAttribute("disabled", "disabled");
        }

        inputWrapper.classList.remove("invalid");
      }); // изменение email в профиле

      form.addEventListener("submit", function (e) {
        e.preventDefault();

        if (re.test(input.value)) {
          btnEditChanged.removeAttribute("disabled");
          inputWrapper.classList.remove("invalid"); // Здесь отправка формы на сервер; window.location = 'xxxx';

          checkProfileEmail(input.value);
          edit.classList.add("visible");
          form.classList.remove("visible");
        } else {
          btnEditChanged.setAttribute("disabled", "disabled");
          inputWrapper.classList.add("invalid");
        }
      });
      btnEdit.addEventListener('click', () => {
        form.classList.add("visible");
        edit.classList.remove("visible");
      });
    }

    if (formLogIn && formSignIn && inputsAuth) {
      const submitBtnSignIn = formSignIn.querySelector('button[type=submit].pop-up-cart__form-btn');
      const submitBtnLoginIn = formLogIn.querySelector('button[type=submit].pop-up-cart__form-btn');
      const inputCheckbox = formSignIn.querySelector(".pop-up-auth__checkbox .custom-check");
      inputsAuth.forEach(function (el) {
        const input = el.querySelector('.pop-up-auth__input');

        if (input) {
          input.addEventListener("input", function (e) {
            el.classList.remove('invalid');
            submitBtnSignIn.removeAttribute("disabled");
            submitBtnLoginIn.removeAttribute("disabled");
          });
        }
      });
      formLogIn.addEventListener('submit', function (e) {
        e.preventDefault();
        validForm(formLogIn, function login() {// вход в систему
        });
      });
      formSignIn.addEventListener('submit', function (e) {
        e.preventDefault();
        validForm(formSignIn, function signin() {// регисрация
        });
      });
      inputCheckbox.addEventListener('change', function () {
        inputsAuth.forEach(function (el) {
          const input = el.querySelector('.pop-up-auth__input');

          if (input) {
            el.classList.remove('invalid');
            submitBtnSignIn.removeAttribute("disabled");
          }
        });
      });
    }
  }

  function checkInputOfAuthForm(input) {
    let isInvalid = false;

    switch (input.name) {
      case "username":
        if (!input.value || input.value?.length < 5 || input.value?.length > 20) isInvalid = true;
        break;

      case "password":
        if (!input.value || !re1.test(input.value)) isInvalid = true;
        break;

      case "email":
        if (!re.test(input.value)) isInvalid = true;
        break;

      case "police":
        if (!input.checked) isInvalid = true;
        break;
    }

    return isInvalid;
  }

  function checkProfileEmail(email) {
    const input = document.querySelector('.profile-info__input[valid]');
    const text = document.querySelector('.profile-edit__text');

    if (email && text && input) {
      text.innerText = email;
      input.value = email;
    }
  }

  function checkHistory() {
    const carts = document.querySelectorAll('.history .cart');
    const emptyText = document.querySelector('.history__carts-empty');
    if (carts && emptyText) if (carts.length === 0) emptyText.style.display = "flex";
  }

  function clearTabs(tabs) {
    tabs.forEach(el => {
      el.classList.remove("active");
    });
  }

  function tabs() {
    const pageWrapper = document.querySelector('.page__wrapper');
    const tabs = document.querySelectorAll('.profile .tab');
    const profileInfo = document.querySelector('.profile__info');
    const pages = document.querySelectorAll('.page-area__wrapper');
    tabs.forEach(function (el, index) {
      el.addEventListener('click', function (e) {
        clearTabs(tabs);

        if (index === 1) {
          profileInfo.classList.add('hide');
          pageWrapper.classList.add('show-history');
        } else {
          profileInfo.classList.remove('hide');
          pageWrapper.classList.remove('show-history');
        }

        this.classList.add('active');
        pages.forEach(function (el, i) {
          if (index !== i) el.classList.add('hide');else el.classList.remove('hide');
        });
      });
    });
  }

  function controlDropwdownProfileBtn() {
    var profileBtn = document.querySelector('[drop-down-btn]');
    var profileContent = document.querySelector('[drop-down-content]');

    if (profileBtn && profileContent) {
      profileBtn.addEventListener('click', function () {
        profileBtn.classList.toggle('active');
        profileContent.classList.toggle('active');
      });
    }
  }

  function checkTtable() {
    const tableEmptyText = document.querySelector('.replenishment__empty');
    const rows = document.querySelectorAll('.replenishment__table tr');
    if (rows && tableEmptyText) if (rows?.length < 2) tableEmptyText.style.display = "flex";
  }

  function checkInputNumber() {
    const btnMinus = document.querySelector('.number-minus');
    const btnPlus = document.querySelector('.number-plus');
    btnMinus.addEventListener('click', function (e) {
      this.nextElementSibling.stepDown();
    });
    btnPlus.addEventListener('click', function (e) {
      this.previousElementSibling.stepUp();
    });
  }

  function checkPrice(price) {
    const btn = document.querySelector('.pop-up-cart__form-empty-balance');
    const groupBtn = document.querySelector('.pop-up-cart__form-replenished-balance');

    if (price > 0) {
      btn.style.display = "none";
      groupBtn.style.display = "block";
    } else {
      groupBtn.style.display = "none";
      btn.style.display = "block";
    }
  }

  function changePopUp() {
    const inputsAuth = document.querySelectorAll('.pop-up-auth__field');
    const popBtnsClose = document.querySelectorAll(".pop-up__btn-close");
    popBtnsClose.forEach(function (element) {
      element.addEventListener("click", function (e) {
        inputsAuth.forEach(function (el) {
          const input = el.querySelector('.pop-up-auth__input');
          const inputCheckbox = document.querySelector("#popupsignin .pop-up-auth__checkbox .custom-check");

          if (input) {
            input.value = "";
            el.classList.remove('invalid');
          }

          if (inputCheckbox) {
            inputCheckbox.checked = false;
          }
        });
      });
    });
  }

  function changePassword() {
    const block = document.querySelector('.password');

    if (block) {
      const input = block.querySelector("input[type=password]");
      const btn = block.querySelector(".btn-visibility");

      if (input && btn) {
        btn.addEventListener('click', function (e) {
          if (input.type === "password") {
            input.type = "text";
            btn.classList.add("visible");
          } else {
            input.type = "password";
            btn.classList.remove("visible");
          }
        });
      }
    }
  }

  function changeCheckboxSideBar() {
    const inputs = document.querySelectorAll(".sidebar-rarities__item input[type=checkbox]");
    if (inputs) inputs.forEach(function (el) {
      el.addEventListener("change", function () {
        const parentEl = el.parentElement;

        if (parentEl) {
          if (el.checked) parentEl.classList.add("checked");else parentEl.classList.remove("checked");
        }
      });
    });
  }

  controlDropwdown();
  controlDropwdownProfileBtn();
  checkInputs();
  checkProfileEmail(currentEmail);
  checkHistory();
  tabs();
  checkTtable();
  checkInputNumber();
  checkPrice(currentPrice);
  changePopUp();
  changePassword();
  changeCheckboxSideBar();
}

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./node_modules/sass-loader/dist/cjs.js!./src/styles/style.scss":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./node_modules/sass-loader/dist/cjs.js!./src/styles/style.scss ***!
  \**********************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_swiper_swiper_bundle_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!../../node_modules/swiper/swiper-bundle.min.css */ "./node_modules/css-loader/dist/cjs.js!./node_modules/swiper/swiper-bundle.min.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! -!../../node_modules/css-loader/dist/cjs.js!../../node_modules/normalize.css/normalize.css */ "./node_modules/css-loader/dist/cjs.js!./node_modules/normalize.css/normalize.css");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4__);
// Imports





var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Regular.woff */ "./src/fonts/OpenSans-Regular.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Regular.woff2 */ "./src/fonts/OpenSans-Regular.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_2___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Regular.ttf */ "./src/fonts/OpenSans-Regular.ttf"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_3___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-SemiBold.woff */ "./src/fonts/OpenSans-SemiBold.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_4___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-SemiBold.woff2 */ "./src/fonts/OpenSans-SemiBold.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_5___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-SemiBold.ttf */ "./src/fonts/OpenSans-SemiBold.ttf"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_6___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Bold.woff */ "./src/fonts/OpenSans-Bold.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_7___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Bold.woff2 */ "./src/fonts/OpenSans-Bold.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_8___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-Bold.ttf */ "./src/fonts/OpenSans-Bold.ttf"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_9___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-ExtraBold.woff */ "./src/fonts/OpenSans-ExtraBold.woff"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_10___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-ExtraBold.woff2 */ "./src/fonts/OpenSans-ExtraBold.woff2"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_11___ = new URL(/* asset import */ __webpack_require__(/*! ../fonts/OpenSans-ExtraBold.ttf */ "./src/fonts/OpenSans-ExtraBold.ttf"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_12___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/arrow.svg */ "./src/images/svg/arrow.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_13___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/hidden-grey.svg */ "./src/images/svg/hidden-grey.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_14___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/visible-grey.svg */ "./src/images/svg/visible-grey.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_15___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/shop.svg */ "./src/images/svg/shop.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_16___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/vopros.svg */ "./src/images/svg/vopros.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_17___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/eye.svg */ "./src/images/svg/eye.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_18___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/app.svg */ "./src/images/svg/app.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_19___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/credit-card-red.svg */ "./src/images/svg/credit-card-red.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_20___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/profile-icon.svg */ "./src/images/svg/profile-icon.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_21___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/log-out.svg */ "./src/images/svg/log-out.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_22___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/check.svg */ "./src/images/svg/check.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_23___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/search.svg */ "./src/images/svg/search.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_24___ = new URL(/* asset import */ __webpack_require__(/*! ../images/svg/email-red.svg */ "./src/images/svg/email-red.svg"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_node_modules_swiper_swiper_bundle_min_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_node_modules_normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_3__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_5___);
var ___CSS_LOADER_URL_REPLACEMENT_6___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_6___);
var ___CSS_LOADER_URL_REPLACEMENT_7___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_7___);
var ___CSS_LOADER_URL_REPLACEMENT_8___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_8___);
var ___CSS_LOADER_URL_REPLACEMENT_9___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_9___);
var ___CSS_LOADER_URL_REPLACEMENT_10___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_10___);
var ___CSS_LOADER_URL_REPLACEMENT_11___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_11___);
var ___CSS_LOADER_URL_REPLACEMENT_12___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_12___);
var ___CSS_LOADER_URL_REPLACEMENT_13___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_13___);
var ___CSS_LOADER_URL_REPLACEMENT_14___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_14___);
var ___CSS_LOADER_URL_REPLACEMENT_15___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_15___);
var ___CSS_LOADER_URL_REPLACEMENT_16___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_16___);
var ___CSS_LOADER_URL_REPLACEMENT_17___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_17___);
var ___CSS_LOADER_URL_REPLACEMENT_18___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_18___);
var ___CSS_LOADER_URL_REPLACEMENT_19___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_19___);
var ___CSS_LOADER_URL_REPLACEMENT_20___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_20___);
var ___CSS_LOADER_URL_REPLACEMENT_21___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_21___);
var ___CSS_LOADER_URL_REPLACEMENT_22___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_22___);
var ___CSS_LOADER_URL_REPLACEMENT_23___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_23___);
var ___CSS_LOADER_URL_REPLACEMENT_24___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_4___default()(___CSS_LOADER_URL_IMPORT_24___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@charset \"UTF-8\";\n*,\n*::before,\n*::after {\n  box-sizing: inherit;\n}\n\n.preload * {\n  transition: none !important;\n}\n\nhtml {\n  box-sizing: border-box;\n  min-height: 100vh;\n}\n\nhtml,\nbody {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\nimg {\n  max-width: 100%;\n  height: auto;\n  display: block;\n}\n\nbutton {\n  border: none;\n  outline: none;\n  background: none;\n  cursor: pointer;\n}\n\na {\n  text-decoration: none;\n  font-family: \"OpenSans-Regular\", arial, sans-serif;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 155%;\n  color: #999999;\n  margin: 0;\n  padding: 0;\n  cursor: pointer;\n  transition: 0.3s linear;\n}\n\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nli,\np,\nul {\n  padding: 0;\n  margin: 0;\n}\n\nh1 {\n  font-size: 64px;\n  line-height: 78px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n}\n\nh2 {\n  font-size: 30px;\n  line-height: 45px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n  margin-bottom: 21px;\n}\n\nul {\n  list-style-type: none;\n  padding: 0;\n  margin: 0;\n}\n\nbody {\n  min-width: 320px;\n  font-family: \"OpenSans-Regular\", arial, sans-serif;\n  font-style: normal;\n  font-weight: 400;\n  color: #ffffff;\n  font-size: 14px;\n  line-height: 17px;\n  background: #151515;\n  display: flex;\n  flex-direction: column;\n  margin: 0;\n  padding: 0;\n  height: 100vh;\n  text-align: center;\n}\n@media (max-width: 767px) {\n  body {\n    font-size: 12px;\n    line-height: 14px;\n  }\n}\n\nmain {\n  flex-grow: 1;\n  position: relative;\n}\nmain > div {\n  display: flex;\n  flex-direction: column;\n  margin: 0;\n  padding: 0;\n  min-height: 100vh;\n  text-align: center;\n}\n\n.visually-hidden {\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  margin: -1px;\n  padding: 0;\n  overflow: hidden;\n  white-space: nowrap;\n  border: 0;\n  clip: rect(0 0 0 0);\n  -webkit-clip-path: inset(100%);\n          clip-path: inset(100%);\n}\n\n.container {\n  max-width: 100%;\n  margin: 0 auto;\n  padding: 0px 10px;\n}\n\ninput[type=radio],\ninput[type=checkbox] {\n  display: none;\n}\n\ninput {\n  background: rgba(248, 248, 248, 0.1);\n  border-radius: 10px;\n  padding: 18px 16px;\n  padding-right: 60px;\n  height: auto;\n  margin: 0;\n  width: 100%;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 17px;\n  outline: none;\n  color: #ffffff;\n  border: 1px solid transparent;\n  position: relative;\n}\ninput:focus {\n  border: 2px solid #df382d;\n}\n\n@font-face {\n  font-family: \"OpenSans-Regular\";\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") format(\"woff\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") format(\"truetype\");\n  font-weight: 400;\n  font-style: normal;\n  font-display: swap;\n}\n@font-face {\n  font-family: \"OpenSans-SemiBold\";\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") format(\"woff\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") format(\"truetype\");\n  font-weight: 600;\n  font-style: normal;\n  font-display: swap;\n}\n@font-face {\n  font-family: \"OpenSans-Bold\";\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") format(\"woff\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") format(\"truetype\");\n  font-weight: 700;\n  font-style: normal;\n  font-display: swap;\n}\n@font-face {\n  font-family: \"OpenSans-ExtraBold\";\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") format(\"woff\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") format(\"woff2\"), url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") format(\"truetype\");\n  font-weight: 800;\n  font-style: normal;\n  font-display: swap;\n}\n.rub::after {\n  content: \"₽\";\n  display: inline-block;\n  padding-left: 6px;\n}\n\n.arrow {\n  position: relative;\n}\n\n.arrow::after {\n  content: \"\";\n  position: absolute;\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ");\n  background-size: contain;\n  background-position: center;\n  background-repeat: no-repeat;\n  width: 25px;\n  height: 25px;\n  right: -5px;\n  top: 50%;\n  transform: translateY(-50%);\n  transition: 0.3s ease-in;\n}\n\n.pop-up {\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  height: 100vh;\n  width: 100vw;\n  z-index: 20;\n  background-color: rgba(0, 0, 0, 0.6);\n  transition: opacity 500ms;\n  visibility: hidden;\n  opacity: 0;\n  overflow: hidden;\n}\n.pop-up button {\n  transition: all 0.3s linear !important;\n}\n.pop-up:target {\n  visibility: visible;\n  opacity: 1;\n}\n.pop-up__inner {\n  max-width: 1042px;\n  width: 100%;\n  background: #1b1b1b;\n  border-radius: 20px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  padding: 92px 99px 84px 95px;\n}\n.pop-up__cart {\n  display: flex;\n  justify-content: space-between;\n}\n.pop-up__btn-close {\n  position: absolute;\n  width: 17px;\n  height: 17px;\n  top: 26px;\n  right: 26px;\n  padding: 0;\n}\n.pop-up__btn-close::before, .pop-up__btn-close::after {\n  content: \"\";\n  display: block;\n  width: 20px;\n  height: 2px;\n  border-radius: 5px;\n  background-color: #C9C9C9;\n  position: absolute;\n}\n.pop-up__btn-close::before {\n  z-index: 11;\n  top: 8px;\n  left: -2px;\n  transform: rotate(-45deg);\n}\n.pop-up__btn-close::after {\n  z-index: 12;\n  top: 8px;\n  left: -2px;\n  transform: rotate(45deg);\n}\n.pop-up__title {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 44.2512px;\n  line-height: 60px;\n  text-transform: uppercase;\n  margin-bottom: 61px;\n}\n.pop-up-cart__img {\n  margin-right: 44px;\n  width: 335px;\n  height: 335px;\n  border-radius: 20px;\n}\n.pop-up-cart__img img {\n  -o-object-fit: cover;\n     object-fit: cover;\n  max-width: none;\n}\n.pop-up-cart__content {\n  width: 100%;\n  text-align: left;\n}\n.pop-up-cart__title {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 36px;\n  line-height: 49px;\n  text-transform: capitalize;\n  margin-bottom: 32px;\n}\n.pop-up-cart__form .cart-info-item {\n  align-items: center;\n}\n.pop-up-cart__form-number {\n  width: 68px;\n  display: flex;\n}\n.pop-up-cart__form-number input {\n  padding: 0;\n  background: none;\n}\n.pop-up-cart__form-number input:focus {\n  border: none;\n}\n.pop-up-cart__form-input {\n  -moz-appearance: textfield;\n  -webkit-appearance: textfield;\n  appearance: textfield;\n  background-color: transparent;\n  width: 44px;\n  padding: 0;\n  text-align: center;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 17.8495px;\n  line-height: 24px;\n  text-transform: capitalize;\n  color: #FFF5F5;\n  text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25), 0px 4px 4px rgba(0, 0, 0, 0.25);\n}\n.pop-up-cart__form-input::-webkit-outer-spin-button, .pop-up-cart__form-input::-webkit-inner-spin-button {\n  display: none;\n}\n.pop-up-cart__form-total {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 40.1613px;\n  line-height: 55px;\n  text-transform: capitalize;\n  margin-top: 28px;\n  margin-bottom: 18px;\n}\n.pop-up-cart__form-btn {\n  display: flex;\n  align-items: center;\n  width: 100%;\n  justify-content: center;\n  padding-top: 18px;\n  padding-bottom: 16px;\n  background: linear-gradient(100.85deg, #DF382D 18.11%, #CF0200 105.96%);\n  border: 3.34677px solid #DF382D;\n  border-radius: 8px;\n}\n.pop-up-cart__form-btn img {\n  margin-right: 14px;\n}\n.pop-up-cart__form-btn p {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 24px;\n  line-height: 33px;\n  text-transform: uppercase;\n  color: #ffffff;\n}\n.pop-up-cart__form-btn-grey {\n  margin-top: 16px;\n  display: flex;\n  justify-content: center;\n  padding-top: 20px;\n  padding-bottom: 19px;\n  background: transparent;\n  border: 3.34677px solid #DF382D;\n  border-radius: 8px;\n}\n.pop-up-cart__form-btn-grey img {\n  margin-right: 14px;\n}\n.pop-up-cart__form-btn-grey p {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 24px;\n  line-height: 33px;\n  text-transform: uppercase;\n  color: #ffffff;\n}\n.pop-up-cart__form-empty-balance {\n  display: none;\n}\n.pop-up-cart__form-replenished-balance {\n  display: none;\n}\n\n.cart-info-item {\n  background-color: #151515;\n  border-radius: 5.57796px;\n  padding: 10px 37px 8px 32px;\n  margin-bottom: 7.5px;\n  display: flex;\n  justify-content: space-between;\n}\n.cart-info-item span {\n  display: inline-block;\n}\n.cart-info-item__label {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n  text-transform: capitalize;\n  color: #C9C9C9;\n}\n.cart-info-item__value {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n  text-transform: capitalize;\n}\n\n.pop-up-auth__field {\n  margin-bottom: 45px;\n  text-align: right;\n}\n.pop-up-auth__field > div {\n  padding: 12px 10px 12px 25px;\n  display: flex;\n  border-bottom: 2px solid #df382d;\n}\n.pop-up-auth__field > div img {\n  margin-right: 25px;\n}\n.pop-up-auth__field small {\n  display: inline-block;\n  padding-top: 8px;\n  padding-right: 13px;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 14px;\n  line-height: 19px;\n  color: #df382d;\n  opacity: 0;\n  transition: all 0.3s;\n  visibility: hidden;\n}\n.pop-up-auth__field .error {\n  width: 0;\n  height: 18px;\n  position: relative;\n  transition: opacity 0.3s ease-in, width 0.3s ease-in, visibility 0.3s ease-in;\n  opacity: 0;\n  visibility: hidden;\n}\n.pop-up-auth__field .error::before, .pop-up-auth__field .error::after {\n  content: \"\";\n  display: block;\n  width: 22px;\n  height: 4px;\n  border-radius: 5px;\n  background-color: #df382d;\n  position: absolute;\n}\n.pop-up-auth__field .error::before {\n  top: 8px;\n  left: -2px;\n  transform: rotate(-45deg);\n}\n.pop-up-auth__field .error::after {\n  top: 8px;\n  left: -2px;\n  transform: rotate(45deg);\n}\n.pop-up-auth__field.invalid .error {\n  width: 18px;\n  opacity: 1;\n  visibility: visible;\n}\n.pop-up-auth__field.invalid > small {\n  opacity: 1;\n  visibility: visible;\n}\n.pop-up-auth__input {\n  background-color: transparent !important;\n}\n.pop-up-auth__input {\n  padding: 0 10px;\n  border-radius: 20px;\n  border: none;\n}\n.pop-up-auth__input:focus {\n  border: none;\n  outline: none;\n}\n.pop-up-auth__input:-webkit-autofill, .pop-up-auth__input:-webkit-autofill:hover, .pop-up-auth__input:-webkit-autofill:focus, .pop-up-auth__input:-webkit-autofill:active {\n  box-shadow: 0 0 0 40px #1b1b1b inset !important;\n  -webkit-text-fill-color: #ffffff !important;\n  color: #ffffff !important;\n  background-image: none !important;\n}\n.pop-up-auth__input:-webkit-autofill, .pop-up-auth__input:-webkit-autofill:hover, .pop-up-auth__input:-webkit-autofill:focus, .pop-up-auth__input:-webkit-autofill:active {\n  border: 1px solid #151515;\n  outline: 0;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 17.7005px;\n  line-height: 24px;\n}\n.pop-up-auth__input::-moz-placeholder {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 17.7005px;\n  line-height: 24px;\n  color: #ffffff;\n}\n.pop-up-auth__input, .pop-up-auth__input::placeholder {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 17.7005px;\n  line-height: 24px;\n  color: #ffffff;\n}\n.pop-up-auth__buttons-login .pop-up-cart__form-btn img {\n  margin-right: 0;\n  margin-left: 14px;\n}\n.pop-up-auth__services {\n  margin-top: 52px;\n  display: flex;\n  justify-content: center;\n}\n.pop-up-auth__service-btn {\n  cursor: pointer;\n}\n.pop-up-auth__service-btn + .pop-up-auth__service-btn {\n  margin-left: 15px;\n}\n.pop-up-auth__checkbox {\n  text-align: left;\n  margin: 44px 0;\n}\n.pop-up-auth__checkbox label {\n  display: inline-flex;\n  align-items: center;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 16px;\n  line-height: 31px;\n}\n.pop-up-auth__checkbox label::before {\n  margin-right: 18px !important;\n}\n.pop-up-auth__checkbox label a {\n  color: #df382d;\n}\n\n.password .btn-visibility {\n  margin-left: 7px;\n  cursor: pointer;\n  width: 35px;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_13___ + ") center no-repeat;\n  transition: all 0.3s ease-in;\n}\n.password .btn-visibility.visible {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_14___ + ") center no-repeat;\n}\n\n.logo {\n  max-width: 314px;\n  width: 100%;\n  margin-right: auto;\n}\n.logo img {\n  width: 100%;\n}\n\n.header {\n  background-color: #1b1b1b;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.header__wrapper {\n  display: flex;\n  gap: 39px;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.header__btns {\n  display: flex;\n  gap: 19px;\n  align-items: center;\n}\n\n.header__list {\n  display: flex;\n  gap: 100px;\n  align-items: center;\n}\n\n.header__logIn {\n  display: flex;\n  cursor: pointer;\n  justify-content: center;\n  align-items: center;\n  max-width: 331px;\n  width: 100%;\n  gap: 11px;\n  background: linear-gradient(100.85deg, #df382d 18.11%, #9f0200 105.95%);\n  border-radius: 10px;\n  padding: 21.5px;\n  margin-left: auto;\n}\n.header__logIn p {\n  font-size: 26px;\n  line-height: 35px;\n  text-transform: uppercase;\n  color: #ffffff;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n}\n.header__logIn img {\n  width: auto;\n}\n\n.header-list__item a {\n  font-size: 18px;\n  text-transform: uppercase;\n  line-height: 25px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.link_shop a,\n.link_show a,\n.link_inventory a,\n.link_help a {\n  position: relative;\n}\n.link_shop a::before,\n.link_show a::before,\n.link_inventory a::before,\n.link_help a::before {\n  content: \"\";\n  position: absolute;\n  left: -28px;\n  width: 20px;\n  height: 20px;\n}\n\n.link_shop {\n  background: #df382d;\n  border-radius: 10px;\n  padding: 18px;\n  width: 180px;\n}\n.link_shop a {\n  padding-left: 20px;\n}\n.link_shop a::before {\n  left: 10px;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_15___ + ") center no-repeat;\n}\n\n.link_help a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_16___ + ") center no-repeat;\n}\n\n.link_show a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_17___ + ") center no-repeat;\n}\n\n.link_inventory a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_18___ + ") center no-repeat;\n}\n\n.dropDown {\n  position: relative;\n  height: 60px;\n}\n.dropDown:hover .hide__items, .dropDown:focus .hide__items {\n  padding-top: 10px;\n  opacity: 1;\n  transform: translateY(0);\n  transition-delay: 0.15s;\n  top: 100%;\n}\n.dropDown:hover .header-languages__current p::before, .dropDown:hover .header-currency__current p::before, .dropDown:focus .header-languages__current p::before, .dropDown:focus .header-currency__current p::before {\n  transform: rotate(180deg);\n}\n\n.header-languages__current {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  height: 100%;\n  gap: 10px;\n  align-items: center;\n  justify-content: center;\n  padding: 7px 44px 7px 19px;\n  cursor: pointer;\n}\n.header-languages__current p {\n  font-size: 20px;\n  line-height: 27px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  text-transform: uppercase;\n  color: #ffffff;\n  position: relative;\n}\n.header-languages__current p::before {\n  content: \"\";\n  position: absolute;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") center no-repeat;\n  width: 25px;\n  height: 25px;\n  right: -100%;\n  bottom: 0;\n  transition: 0.3s ease-in;\n}\n\n.hide-items__wrapper {\n  background: #2f2f2f;\n  border-radius: 10px;\n  padding: 16px 10px;\n  display: flex;\n  z-index: 1;\n  flex-direction: column;\n  gap: 8px;\n  width: 100%;\n}\n\n.hide__items {\n  position: absolute;\n  z-index: 100;\n  width: 100%;\n  transform: translateY(-30px);\n  opacity: 0;\n  transition: transform 0.5s linear 0.1s, opacity 0.1s linear 0.1s, height 0.1s linear 0.1s;\n  top: -9999px;\n  left: 0;\n  height: 0;\n  padding: 0;\n}\n\n.hide__item {\n  transition: 0.3s linear;\n}\n.hide__item a {\n  gap: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  line-height: 25px;\n  text-transform: uppercase;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n}\n.hide__item img {\n  width: 40px;\n}\n.hide__item:hover, .hide__item:focus {\n  background: #4c4c4c;\n  border-radius: 10px;\n}\n\n.header__currency {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  gap: 10px;\n  align-items: center;\n  justify-content: center;\n  padding: 7px 44px 7px 19px;\n  cursor: pointer;\n}\n.header__currency p {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: uppercase;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n  position: relative;\n}\n.header__currency p::before {\n  content: \"\";\n  position: absolute;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") center no-repeat;\n  width: 25px;\n  height: 25px;\n  right: -25px;\n  bottom: 0;\n  transition: 0.3s ease-in;\n}\n\n.header__info-user {\n  display: flex;\n  margin-left: 94px;\n  position: relative;\n}\n.header__info-user .hide__items {\n  top: 100%;\n  transform: translateY(0);\n  transition: opacity 0.5s;\n  visibility: hidden;\n}\n.header__info-user .hide__item {\n  text-align: left;\n}\n.header__info-user .hide__item a {\n  width: 100%;\n  padding: 9px 0 7px 48px;\n  font-size: 16px;\n  line-height: 22px;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  text-transform: capitalize;\n  display: inline-block;\n  position: relative;\n}\n.header__info-user .hide__item a::before {\n  content: \"\";\n  display: block;\n  position: absolute;\n  left: 17px;\n  top: 50%;\n  transform: translateY(-50%);\n  width: 21px;\n  height: 21px;\n}\n.header__info-user .hide__item:nth-child(1) a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_19___ + ") center no-repeat;\n}\n.header__info-user .hide__item:nth-child(2) a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_20___ + ") center no-repeat;\n}\n.header__info-user .hide__item:nth-child(3) a::before {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_21___ + ") center no-repeat;\n}\n.header__bill {\n  display: flex;\n  align-items: center;\n  padding: 8px 14px;\n  border-radius: 8.44291px;\n  background: #2f2f2f;\n}\n.header__profile {\n  cursor: pointer;\n  width: 84px;\n  margin-left: 25px;\n}\n.header-bill__img {\n  margin-right: 14px;\n}\n.header-bill__value {\n  line-height: 24px;\n  font-size: 18px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  margin-right: 14px;\n  white-space: nowrap;\n}\n.header-bill__btn {\n  background: #df382d;\n  border-radius: 8.44291px;\n  padding: 14px;\n  cursor: pointer;\n}\n\n.header-info-user__options {\n  max-width: 175px;\n  left: auto;\n  right: 0;\n  padding-top: 14px;\n}\n\n.header-profile__img {\n  border-radius: 8.44291px;\n  width: 60px;\n  height: 60px;\n}\n[drop-down-btn].active > .arrow::after {\n  transform: rotate(180deg) translateY(50%);\n}\n\n[drop-down-content].active {\n  opacity: 1;\n  visibility: visible;\n  top: 100%;\n  height: auto;\n}\n\n.sidebar__socials {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: auto;\n}\n\n.sidebar__wrapper {\n  padding: 21px 32px;\n  display: flex;\n  height: 100%;\n  flex-direction: column;\n  gap: 31px;\n  background: #1b1b1b;\n  align-items: flex-start;\n}\n.sidebar__wrapper > div {\n  z-index: 2;\n  width: 100%;\n}\n\n.sidebar {\n  max-width: 357px;\n  width: 100%;\n  position: relative;\n}\n\n.sidebar-item__title {\n  margin-bottom: 19px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-ExtraBold\", arial, sans-serif;\n  font-weight: 800;\n  font-size: 26px;\n  line-height: 35px;\n}\n\n.sidebar-types__area {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  grid-gap: 31px;\n  justify-items: start;\n}\n\n.sidebar-types__item label {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n  display: inline-flex;\n  align-items: center;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n  cursor: pointer;\n}\n\n.custom-check + label::before {\n  content: \"\";\n  display: inline-block;\n  width: 31px;\n  height: 31px;\n  flex-shrink: 0;\n  flex-grow: 0;\n  border: 2px solid #df382d;\n  margin-right: 0.5em;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: 50% 50%;\n  border-radius: 10px;\n}\n\n.custom-check:checked + label::before {\n  background-color: #df382d;\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_22___ + ");\n  background-size: 80%;\n}\n\n.sidebar-rarities_current {\n  position: relative;\n  width: 100%;\n}\n.sidebar-rarities_current p {\n  font-size: 20px;\n  line-height: 27px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  color: #ffffff;\n  cursor: pointer;\n}\n.sidebar-rarities_current p::after {\n  content: \"\";\n  position: absolute;\n  width: 15px;\n  height: 15px;\n  right: 0;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") center no-repeat;\n  transform: rotate(270deg);\n  bottom: 5px;\n  transition: 0.3s linear;\n}\n\n.sidebar-rarities {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n  padding: 17px 22px 16px 27px;\n}\n.sidebar-rarities:hover .hide__items, .sidebar-rarities:focus .hide__items {\n  top: 0;\n  padding-top: 0;\n  left: 100%;\n  padding-left: 6px;\n}\n.sidebar-rarities:hover .sidebar-rarities_current p::after, .sidebar-rarities:focus .sidebar-rarities_current p::after {\n  transform: rotate(90deg);\n}\n\n.sidebar-rarities__item.checked {\n  background: #4c4c4c;\n  border-radius: 10px;\n}\n\n.sidebar-currency__item input::-webkit-outer-spin-button, .sidebar-currency__item input::-webkit-inner-spin-button {\n  display: none;\n}\n\n.sidebar-rarities__item label {\n  font-size: 18px;\n  line-height: 25px;\n  text-transform: capitalize;\n  color: #c9c9c9;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n\n.sidebar__img {\n  z-index: 1 !important;\n}\n\n.sidebar__img {\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n  left: 0;\n}\n\n.sidebar-rarities.dropDown {\n  display: flex;\n  width: 100%;\n}\n.sidebar-rarities__item {\n  display: flex;\n  align-items: center;\n  padding: 9px 26px;\n  cursor: pointer;\n}\n.sidebar-rarities__item .dot {\n  display: block;\n  width: 17px;\n  height: 17px;\n  margin-right: 17px;\n  border-radius: 4px;\n}\n\n.sidebar-currency__wrapper {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 7px;\n}\n\n.sidebar-currency__item {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  padding: 10px 13px;\n  gap: 9px;\n}\n.sidebar-currency__item label {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n.sidebar-currency__item input {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  padding: 0;\n  border: none;\n  height: 27px;\n  background: transparent;\n}\n.sidebar-currency__item input:focus, .sidebar-currency__item input:hover {\n  border: none;\n}\n\n.sidebar-currency__rasdel {\n  width: 10px;\n  height: 2px;\n  background: #df382d;\n}\n\n.page__wrapper {\n  display: flex;\n  align-items: stretch;\n  gap: 50px;\n}\n\n.pages__statusPanel {\n  margin-bottom: 50px;\n}\n\n.page__area {\n  margin-top: 50px;\n}\n\n.carts {\n  display: grid;\n  grid-template-columns: repeat(6, 1fr);\n  grid-gap: 46px;\n  padding-right: 41px;\n  overflow-y: auto;\n  height: calc(100vh - 294px);\n}\n.carts {\n  scrollbar-width: thin;\n  scrollbar-color: #4A4A4A #272424;\n}\n.carts::-webkit-scrollbar {\n  width: 19px;\n}\n.carts::-webkit-scrollbar-track {\n  border-radius: 10px;\n  background: #272424;\n}\n.carts::-webkit-scrollbar-thumb {\n  background-color: #4A4A4A;\n  border-radius: 20px;\n  border: 3px solid #272424;\n}\n\n.cart {\n  cursor: pointer;\n}\n\n.form-search {\n  max-width: 564px;\n  width: 100%;\n  position: relative;\n}\n.form-search input {\n  height: 65px;\n  padding: 19px 100px;\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n.form-search input::-moz-placeholder {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n.form-search input::placeholder {\n  font-size: 20px;\n  line-height: 27px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n.form-search::before {\n  content: \"\";\n  position: absolute;\n  width: 25px;\n  height: 26px;\n  left: 50px;\n  transform: translate(0%, 90%);\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_23___ + ") center no-repeat;\n}\n\n.cart__img img {\n  border-radius: 10px;\n  max-height: 197px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  min-height: 197px;\n}\n\n.cart__content {\n  margin-top: 6px;\n  padding: 0px 9px;\n}\n.cart__content p {\n  text-align: left;\n  font-size: 16px;\n  line-height: 22px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n}\n\n.form__selected-wrapper {\n  display: flex;\n}\n\n.form__selected-wrapper.active .form__selected-btn {\n  border: 2px solid #df382d;\n}\n\n.form__selected-btn {\n  background: #4d4d4d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 65px;\n  height: 65px;\n  position: relative;\n  z-index: 10;\n  left: 19px;\n}\n.form__selected-btn img {\n  width: 38px;\n  height: 38px;\n}\n\n.form__select {\n  display: flex;\n  flex-direction: column;\n  position: relative;\n}\n\n.form__option-selected {\n  position: relative;\n  z-index: 1;\n  order: 0;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n  width: 100%;\n  padding: 0.7em 1.425em;\n  border: 1px solid #182f43;\n  transition: transform 0.1s linear;\n  font-size: 20px;\n  line-height: 27px;\n  color: #ffffff;\n  background: #2f2f2f;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  gap: 11px;\n}\n.form__option-selected img {\n  width: 24px;\n  height: 24px;\n}\n\n.form__options-container {\n  position: absolute;\n  z-index: 3;\n  top: calc(100% + 5px);\n  max-height: 273px;\n  padding: 16px 8px;\n  opacity: 0;\n  overflow: hidden;\n  background: #2f2f2f;\n  border-radius: 10px;\n  pointer-events: none;\n  order: 1;\n  transition: opacity 0.1s ease-in-out;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n  left: 19px;\n}\n\n.form__option {\n  padding: 5px 25px;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n  line-height: normal;\n  transition: color 0.1s linear;\n}\n.form__option:hover {\n  background: #4c4c4c;\n  border-radius: 10px;\n}\n\n.form__option input {\n  display: none;\n}\n\n.form__option label {\n  cursor: pointer;\n  font-size: 14px;\n  display: flex;\n  gap: 11px;\n  align-items: center;\n}\n.form__option label img {\n  width: 24px;\n  height: 24px;\n}\n\n.form__options-container.active {\n  opacity: 1;\n  overflow-y: auto;\n  pointer-events: all;\n}\n\n.pages__statusPanel {\n  display: flex;\n  align-items: center;\n}\n\n.profile {\n  max-width: 1854px;\n  margin: 0 auto;\n  padding-top: 39px;\n}\n.profile .page__wrapper {\n  display: grid;\n  grid-template-columns: auto minmax(auto, 1150px);\n  grid-auto-rows: auto 1fr;\n  grid-template-areas: \"tabs area\" \"info area\";\n}\n.profile .page__wrapper.show-history {\n  display: block;\n}\n.profile .page__area {\n  grid-area: area;\n  margin-top: 0;\n  padding: 31px 42px;\n  background-color: #1b1b1b;\n  border-radius: 17.5728px;\n}\n.profile .carts {\n  gap: 34px;\n  height: calc(100vh - 330px);\n}\n\n.profile__tabs {\n  display: flex;\n  grid-area: tabs;\n  margin-bottom: 47px;\n}\n.profile__tabs .tab {\n  display: flex;\n  cursor: pointer;\n  align-items: center;\n  border-radius: 10px;\n  padding: 8px 25px 14px 28px;\n}\n.profile__tabs .tab.active {\n  background: linear-gradient(100.85deg, #df382d 18.11%, #9f0200 105.95%);\n}\n.profile__tabs .tab p {\n  font-size: 24px;\n  line-height: 33px;\n  text-transform: capitalize;\n  color: #ffffff;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n}\n.profile__tabs .tab img {\n  width: 22px;\n  height: 30px;\n  margin-right: 14px;\n}\n.profile__tabs .tab + .tab {\n  margin-left: 40px;\n}\n\n.profile__info {\n  grid-area: info;\n  opacity: 1;\n  visibility: visible;\n  height: auto;\n  transition: opacity 0.3s;\n}\n.profile__info h3 {\n  text-align: left;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 30px;\n  line-height: 41px;\n  text-transform: capitalize;\n}\n.profile__info.hide {\n  opacity: 0;\n  visibility: hidden;\n  height: 0;\n  overflow: hidden;\n}\n\n.profile-info__content {\n  margin-top: 30px;\n  display: flex;\n  align-items: center;\n  padding-bottom: 33px;\n  margin-bottom: 27px;\n  border-bottom: 0.878641px solid #4c4c4c;\n}\n.profile-info__large-items {\n  text-align: left;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n}\n.profile-info__large-items span {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n}\n.profile-info__edit {\n  display: flex;\n  opacity: 0;\n  visibility: hidden;\n  z-index: -10;\n  transition: opacity 0.3s;\n  height: 0;\n  overflow: hidden;\n  margin: 0;\n}\n.profile-info__edit.visible {\n  opacity: 1;\n  visibility: visible;\n  z-index: 1;\n  height: auto;\n  margin-top: 49px;\n  overflow: visible;\n}\n.profile-info__form {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-end;\n  opacity: 0;\n  visibility: hidden;\n  z-index: -10;\n  transition: opacity 0.3s;\n  height: 0;\n  overflow: visible;\n  margin: 0;\n}\n.profile-info__form.visible {\n  opacity: 1;\n  visibility: visible;\n  z-index: 1;\n  height: auto;\n  margin-top: 30px;\n}\n.profile-info__form > div {\n  text-align: right;\n  margin-right: 41px;\n  width: 100%;\n}\n.profile-info__form > div > small {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 14px;\n  line-height: 19px;\n  color: #df382d;\n  margin-bottom: 7px;\n  display: inline-block;\n  opacity: 0;\n  transition: all 0.3s;\n  visibility: hidden;\n}\n.profile-info__form > div.invalid > small {\n  opacity: 1;\n  visibility: visible;\n}\n.profile-info__form > div.invalid .profile-info__input-wrapper {\n  border: 1.5px solid #df382d;\n}\n.profile-info__avatar {\n  border-radius: 8.44291px;\n  width: 70px;\n  height: 70px;\n  margin-right: 24px;\n}\n.profile-info__username {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 17.5728px;\n  line-height: 24px;\n  text-transform: capitalize;\n}\n.profile-info__personal {\n  background-color: #1b1b1b;\n  border-radius: 17.5728px;\n  padding: 40px 42px;\n  margin-bottom: 40px;\n}\n.profile-info__email {\n  background-color: #1b1b1b;\n  border-radius: 17.5728px;\n  padding: 40px 42px;\n}\n.profile-info__input-wrapper {\n  position: relative;\n  padding-left: 54px;\n  background-color: #151515;\n  border: 2px solid transparent;\n  border-radius: 10px;\n}\n.profile-info__input-wrapper[focus-within] {\n  border: 2px solid #df382d;\n}\n.profile-info__input-wrapper:focus-within {\n  border: 2px solid #df382d;\n}\n.profile-info__input-wrapper::before {\n  content: \"\";\n  display: block;\n  position: absolute;\n  width: 22px;\n  height: 22px;\n  left: 17px;\n  top: 50%;\n  transform: translateY(-50%);\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_24___ + ") center no-repeat;\n}\n.profile-info__input {\n  display: inline-block;\n  width: 100%;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n  background-color: inherit;\n  border: 2px solid transparent;\n  border-radius: 20px;\n  padding: 10px;\n}\n.profile-info__input:focus {\n  border: 1px solid #151515;\n}\n.profile-info__input:-webkit-autofill, .profile-info__input:-webkit-autofill:hover, .profile-info__input:-webkit-autofill:focus, .profile-info__input:-webkit-autofill:active {\n  box-shadow: 0 0 0 40px #151515 inset !important;\n  -webkit-text-fill-color: #ffffff !important;\n  color: #ffffff !important;\n  background-image: none !important;\n}\n.profile-info__input:-webkit-autofill, .profile-info__input:-webkit-autofill:hover, .profile-info__input:-webkit-autofill:focus, .profile-info__input:-webkit-autofill:active {\n  border: 1px solid #151515;\n  outline: 0;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n}\n.profile-info__text {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n  margin-top: 53px;\n  text-align: left;\n}\n.profile-info__btn-edit-email {\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 18px;\n  line-height: 25px;\n  text-transform: uppercase;\n  padding: 19px;\n  transition: all 0.3s;\n  color: #df382d;\n}\n.profile-info__btn-edit-email[disabled] {\n  color: #511511;\n}\n\n.profile-edit__text {\n  display: inline-block;\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 25px;\n}\n.profile-edit__btn-change-email {\n  cursor: pointer;\n  margin-left: 15px;\n  width: 22px;\n  height: 22px;\n}\n\n.profile .page-area__wrapper {\n  opacity: 1;\n  visibility: visible;\n  transition: opacity 0.3s;\n}\n.profile .page-area__wrapper.hide {\n  overflow: hidden;\n  width: 0;\n  opacity: 0;\n  visibility: hidden;\n  height: 0;\n}\n.profile .history__title {\n  text-align: left;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-weight: 700;\n  font-size: 30px;\n  line-height: 41px;\n  margin-bottom: 48px;\n}\n.profile .history .cart__img img {\n  max-height: 140px;\n  min-height: auto;\n  min-width: 140px;\n}\n.profile .history__carts-empty {\n  justify-content: center;\n  align-items: center;\n  height: calc(100% - 89px);\n  display: none;\n}\n.profile .history__carts-empty span {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 20px;\n  line-height: 27px;\n  color: #4c4c4c;\n}\n.profile .replenishment {\n  overflow-y: auto;\n  display: block;\n  height: calc(100vh - 370px);\n}\n.profile .replenishment {\n  scrollbar-width: thin;\n  scrollbar-color: #4A4A4A #272424;\n}\n.profile .replenishment::-webkit-scrollbar {\n  width: 19px;\n}\n.profile .replenishment::-webkit-scrollbar-track {\n  background: #272424;\n  border-radius: 10px;\n}\n.profile .replenishment::-webkit-scrollbar-thumb {\n  background-color: #4A4A4A;\n  border-radius: 20px;\n  border: 3px solid #272424;\n}\n.profile .replenishment__table {\n  max-width: 1241px;\n  margin: 0 auto;\n}\n.profile .replenishment__table, .profile .replenishment__table tbody {\n  width: 100%;\n}\n.profile .replenishment__table tr {\n  display: flex;\n  padding: 26px 0;\n}\n.profile .replenishment__table tr + tr {\n  border-bottom: 1px solid #4c4c4c;\n}\n.profile .replenishment__table td, .profile .replenishment__table th {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 20%;\n}\n.profile .replenishment__table tr:nth-child(1) > td {\n  display: flex;\n  align-items: center;\n}\n.profile .replenishment__table tr:nth-child(1) > td span {\n  margin-left: 14px;\n  font-family: \"OpenSans-Bold\", arial, sans-serif;\n  font-weight: 700;\n  font-size: 24px;\n  line-height: 33px;\n  text-transform: uppercase;\n}\n.profile .replenishment__table tr:not(:first-child) > td {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 20px;\n  line-height: 27px;\n  color: #FDFFFD;\n}\n.profile .replenishment__table .status {\n  padding-left: 30px;\n  position: relative;\n}\n.profile .replenishment__table .status::before {\n  content: \"\";\n  position: absolute;\n  display: block;\n  left: 0;\n  top: 50%;\n  transform: translateY(-50%);\n  width: 11px;\n  height: 11px;\n  border-radius: 2px;\n}\n.profile .replenishment__table .status.processing::before {\n  background-color: #FFD43A;\n}\n.profile .replenishment__table .status.translated::before {\n  background-color: #5BDF2D;\n}\n.profile .replenishment__table .status.canceled::before {\n  background-color: #777;\n}\n.profile .replenishment__empty {\n  justify-content: center;\n  align-items: center;\n  height: calc(100% - 87px);\n  display: none;\n}\n.profile .replenishment__empty span {\n  font-family: \"OpenSans-SemiBold\", arial, sans-serif;\n  font-weight: 600;\n  font-size: 20px;\n  line-height: 27px;\n  color: #4c4c4c;\n}", "",{"version":3,"sources":["webpack://./src/styles/style.scss","webpack://./src/styles/global/global.scss","webpack://./src/styles/global/variables.scss","webpack://./src/styles/global/fonts.scss","webpack://./src/styles/global/basic.scss","webpack://./src/styles/blocks/pop-up.scss","webpack://./src/styles/blocks/header.scss","webpack://./src/styles/blocks/sidebar.scss","webpack://./src/styles/blocks/test.scss","webpack://./src/styles/blocks/profile.scss"],"names":[],"mappings":"AAAA,gBAAgB;ACAhB;;;EAGE,mBAAA;ADIF;;ACFA;EACE,2BAAA;ADKF;;ACDA;EACE,sBAAA;EACA,iBAAA;ADIF;;ACAA;;EAEE,mCAAA;EACA,kCAAA;ADGF;;ACAA;EACE,eAAA;EACA,YAAA;EACA,cAAA;ADGF;;ACAA;EACE,YAAA;EACA,aAAA;EACA,gBAAA;EACA,eAAA;ADGF;;ACAA;EACE,qBAAA;EACA,kDCnBS;EDoBT,kBAAA;EACA,gBAAA;EACA,eAAA;EACA,iBAAA;EACA,cAAA;EACA,SAAA;EACA,UAAA;EACA,eAAA;EACA,uBAAA;ADGF;;ACAA;;;;;;;;;EASE,UAAA;EACA,SAAA;ADGF;;ACAA;EACE,eAAA;EACA,iBAAA;EACA,+CC7Cc;ED8Cd,gBCxCK;EDyCL,cCpCM;AFuCR;;ACAA;EACE,eAAA;EACA,iBAAA;EACA,+CCrDc;EDsDd,gBChDK;EDiDL,cC5CM;ED6CN,mBAAA;ADGF;;ACAA;EACE,qBAAA;EACA,UAAA;EACA,SAAA;ADGF;;ACAA;EACE,gBAAA;EACA,kDCrES;EDsET,kBAAA;EACA,gBAAA;EACA,cC3DM;ED4DN,eAAA;EACA,iBAAA;EACA,mBC7DQ;ED+DR,aAAA;EACA,sBAAA;EACA,SAAA;EACA,UAAA;EAEA,aAAA;EACA,kBAAA;ADCF;ACAE;EAjBF;IAkBI,eAAA;IACA,iBAAA;EDGF;AACF;;ACAA;EACE,YAAA;EACA,kBAAA;ADGF;ACFE;EACE,aAAA;EACA,sBAAA;EACA,SAAA;EACA,UAAA;EACA,iBAAA;EACA,kBAAA;ADIJ;;ACAA;EACE,kBAAA;EACA,UAAA;EACA,WAAA;EACA,YAAA;EACA,UAAA;EACA,gBAAA;EACA,mBAAA;EACA,SAAA;EACA,mBAAA;EACA,8BAAA;UAAA,sBAAA;ADGF;;ACAA;EACE,eAAA;EACA,cAAA;EACA,iBAAA;ADGF;;ACAA;;EAEE,aAAA;ADGF;;ACAA;EACE,oCAAA;EACA,mBAAA;EACA,kBAAA;EACA,mBAAA;EACA,YAAA;EACA,SAAA;EACA,WAAA;EACA,mDCtIkB;EDuIlB,gBClIO;EDmIP,eAAA;EACA,iBAAA;EACA,aAAA;EACA,cC/HM;EDgIN,6BAAA;EACA,kBAAA;ADGF;ACFE;EACE,yBAAA;ADIJ;;AGtKA;EACE,+BAAA;EACA,gLAAA;EAGA,gBAAA;EACA,kBAAA;EACA,kBAAA;AHuKF;AGpKA;EACE,gCAAA;EACA,gLAAA;EAGA,gBAAA;EACA,kBAAA;EACA,kBAAA;AHoKF;AGjKA;EACE,4BAAA;EACA,gLAAA;EAGA,gBAAA;EACA,kBAAA;EACA,kBAAA;AHiKF;AG9JA;EACE,iCAAA;EACA,kLAAA;EAGA,gBAAA;EACA,kBAAA;EACA,kBAAA;AH8JF;AInMA;EACI,YAAA;EACA,qBAAA;EACA,iBAAA;AJqMJ;;AInMA;EACI,kBAAA;AJsMJ;;AIpMA;EACI,WAAA;EACA,kBAAA;EACA,0DAAA;EACA,wBAAA;EACA,2BAAA;EACA,4BAAA;EACA,WAAA;EACA,YAAA;EACA,WAAA;EACA,QAAA;EACA,2BAAA;EACA,wBAAA;AJuMJ;;AK3NA;EACI,eAAA;EACA,MAAA;EACA,SAAA;EACA,OAAA;EACA,QAAA;EACA,aAAA;EACA,YAAA;EACA,WAAA;EACA,oCAAA;EAEA,yBAAA;EACA,kBAAA;EACA,UAAA;EACA,gBAAA;AL6NJ;AK3NI;EACI,sCAAA;AL6NR;AK1NI;EACI,mBAAA;EACA,UAAA;AL4NR;AKzNI;EACI,iBAAA;EACA,WAAA;EACA,mBHgBG;EGfH,mBAAA;EACA,kBAAA;EACA,QAAA;EACA,SAAA;EACA,gCAAA;EACA,4BAAA;AL2NR;AKxNI;EACI,aAAA;EACA,8BAAA;AL0NR;AKvNI;EACI,kBAAA;EACA,WAAA;EACA,YAAA;EACA,SAAA;EACA,WAAA;EACA,UAAA;ALyNR;AKvNQ;EACI,WAAA;EACA,cAAA;EACA,WAAA;EACA,WAAA;EACA,kBAAA;EACA,yBHpBH;EGqBG,kBAAA;ALyNZ;AKtNQ;EACI,WAAA;EACA,QAAA;EACA,UAAA;EACA,yBAAA;ALwNZ;AKtNQ;EACI,WAAA;EACA,QAAA;EACA,UAAA;EACA,wBAAA;ALwNZ;AKrNI;EACI,+CHtDQ;EGuDR,gBHjDD;EGkDC,oBAAA;EACA,iBAAA;EACA,yBAAA;EACA,mBAAA;ALuNR;AK/MI;EACI,kBAAA;EACA,YAAA;EACA,aAAA;EACA,mBAAA;ALiNR;AK/MQ;EACI,oBAAA;KAAA,iBAAA;EACA,eAAA;ALiNZ;AK9MI;EACI,WAAA;EACA,gBAAA;ALgNR;AK9MI;EACI,+CHnFQ;EGoFR,gBH9ED;EG+EC,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,mBAAA;ALgNR;AK3MQ;EACI,mBAAA;AL6MZ;AKxMQ;EACI,WAAA;EACA,aAAA;AL0MZ;AKxMY;EACI,UAAA;EACA,gBAAA;AL0MhB;AKxMgB;EACI,YAAA;AL0MpB;AKtMQ;EACI,0BAAA;EACA,6BAAA;EACA,qBAAA;EACA,6BAAA;EACA,WAAA;EACA,UAAA;EACA,kBAAA;EACA,mDHzHQ;EG0HR,gBHpHL;EGqHK,oBAAA;EACA,iBAAA;EACA,0BAAA;EACA,cAAA;EAEA,6EAAA;ALuMZ;AKpMY;EAEI,aAAA;ALqMhB;AKlMQ;EACI,+CHxII;EGyIJ,gBHnIL;EGoIK,oBAAA;EACA,iBAAA;EACA,0BAAA;EACA,gBAAA;EACA,mBAAA;ALoMZ;AKlMQ;EACI,aAAA;EACA,mBAAA;EACA,WAAA;EACA,uBAAA;EACA,iBAAA;EACA,oBAAA;EACA,uEAAA;EACA,+BAAA;EACA,kBAAA;ALoMZ;AKnMY;EACI,kBAAA;ALqMhB;AKnMY;EACI,+CH9JA;EG+JA,gBHzJT;EG0JS,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,cHxJR;AF6VR;AKlMY;EACI,gBAAA;EACA,aAAA;EACA,uBAAA;EACA,iBAAA;EACA,oBAAA;EACA,uBAAA;EACA,+BAAA;EACA,kBAAA;ALoMhB;AKnMgB;EACI,kBAAA;ALqMpB;AKnMgB;EACI,+CHnLJ;EGoLI,gBH9Kb;EG+Ka,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,cH7KZ;AFkXR;AKjMQ;EACI,aAAA;ALmMZ;AKjMQ;EACI,aAAA;ALmMZ;;AK/LA;EACI,yBHzLM;EG0LN,wBAAA;EACA,2BAAA;EACA,oBAAA;EACA,aAAA;EACA,8BAAA;ALkMJ;AKhMI;EACI,qBAAA;ALkMR;AK/LI;EACI,mDHlNY;EGmNZ,gBH7MD;EG8MC,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cHtMC;AFuYT;AK/LI;EACI,mDH1NY;EG2NZ,gBHrND;EGsNC,eAAA;EACA,iBAAA;EACA,0BAAA;ALiMR;;AK5LI;EACI,mBAAA;EACA,iBAAA;AL+LR;AK9LQ;EACI,4BAAA;EACA,aAAA;EACA,gCAAA;ALgMZ;AK/LY;EACI,kBAAA;ALiMhB;AK9LQ;EACI,qBAAA;EACA,gBAAA;EACA,mBAAA;EACA,mDHlPQ;EGmPR,gBH7OL;EG8OK,eAAA;EACA,iBAAA;EACA,cHxON;EGyOM,UAAA;EACA,oBAAA;EACA,kBAAA;ALgMZ;AK9LQ;EACI,QAAA;EACA,YAAA;EACA,kBAAA;EACA,6EAAA;EACA,UAAA;EACA,kBAAA;ALgMZ;AK/LY;EACI,WAAA;EACA,cAAA;EACA,WAAA;EACA,WAAA;EACA,kBAAA;EACA,yBH1PV;EG2PU,kBAAA;ALiMhB;AK/LY;EACI,QAAA;EACA,UAAA;EACA,yBAAA;ALiMhB;AK/LY;EACI,QAAA;EACA,UAAA;EACA,wBAAA;ALiMhB;AK5LY;EACQ,WAAA;EACA,UAAA;EACA,mBAAA;AL8LpB;AK5LY;EACI,UAAA;EACA,mBAAA;AL8LhB;AKxLI;EAEI,wCAAA;AL4LR;AK9LI;EACI,eAAA;EAEA,mBAAA;EACA,YAAA;AL0LR;AKzLQ;EACI,YAAA;EACA,aAAA;AL2LZ;AKzLQ;EAII,+CAAA;EAOA,2CAAA;EACA,yBAAA;EACA,iCAAA;ALwLZ;AKrMQ;EAKI,yBAAA;EACA,UAAA;EACA,mDHrTQ;EGsTR,gBHhTL;EGiTK,oBAAA;EACA,iBAAA;AL2LZ;AKrLI;EACI,mDH/TY;EGgUZ,gBH1TD;EG2TC,oBAAA;EACA,iBAAA;EACA,cHvTA;AF8eR;AK5LI;EACI,mDH/TY;EGgUZ,gBH1TD;EG2TC,oBAAA;EACA,iBAAA;EACA,cHvTA;AF8eR;AKnLY;EACI,eAAA;EACA,iBAAA;ALqLhB;AKjLI;EACI,gBAAA;EACA,aAAA;EACA,uBAAA;ALmLR;AKjLI;EACI,eAAA;ALmLR;AKlLQ;EACI,iBAAA;ALoLZ;AKjLI;EACI,gBAAA;EACA,cAAA;ALmLR;AK/KQ;EACI,oBAAA;EACA,mBAAA;EACA,mDHjWQ;EGkWR,gBH5VL;EG6VK,eAAA;EACA,iBAAA;ALiLZ;AK/KY;EACI,6BAAA;ALiLhB;AK/KY;EACI,cH5VV;AF6gBN;;AKzKI;EACI,gBAAA;EACA,eAAA;EACA,WAAA;EACA,qEAAA;EACA,4BAAA;AL4KR;AK3KQ;EACI,qEAAA;AL6KZ;;AMzjBA;EACE,gBAAA;EACA,WAAA;EACA,kBAAA;AN4jBF;AM3jBE;EACE,WAAA;AN6jBJ;;AM1jBA;EACE,yBJ+BU;EI9BV,iBAAA;EACA,oBAAA;AN6jBF;;AM1jBA;EACE,aAAA;EACA,SAAA;EACA,mBAAA;EACA,8BAAA;AN6jBF;;AM3jBA;EACE,aAAA;EACA,SAAA;EACA,mBAAA;AN8jBF;;AM5jBA;EACE,aAAA;EACA,UAAA;EACA,mBAAA;AN+jBF;;AM5jBA;EACE,aAAA;EACA,eAAA;EACA,uBAAA;EACA,mBAAA;EACA,gBAAA;EACA,WAAA;EACA,SAAA;EACA,uEAAA;EACA,mBAAA;EACA,eAAA;EACA,iBAAA;AN+jBF;AM9jBE;EACE,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,cJhBI;EIiBJ,+CJ5BY;EI6BZ,gBJvBG;AFulBP;AM9jBE;EACE,WAAA;ANgkBJ;;AM3jBE;EACE,eAAA;EACA,yBAAA;EACA,iBAAA;EACA,+CJzCY;EI0CZ,gBJpCG;EIqCH,cJhCI;EIiCJ,aAAA;EACA,mBAAA;EACA,uBAAA;AN8jBJ;;AMtjBE;;;;EACE,kBAAA;AN4jBJ;AM3jBI;;;;EACE,WAAA;EACA,kBAAA;EACA,WAAA;EAEA,WAAA;EACA,YAAA;AN+jBN;;AM1jBA;EACE,mBJvDI;EIwDJ,mBAAA;EACA,aAAA;EACA,YAAA;AN6jBF;AM5jBE;EACE,kBAAA;AN8jBJ;AM7jBI;EACE,UAAA;EACA,qEAAA;AN+jBN;;AMxjBI;EACE,qEAAA;AN2jBN;;AMpjBI;EACE,qEAAA;ANujBN;;AMhjBI;EACE,qEAAA;ANmjBN;;AM7iBA;EACE,kBAAA;EACA,YAAA;ANgjBF;AM7iBI;EACE,iBAAA;EACA,UAAA;EACA,wBAAA;EACA,uBAAA;EACA,SAAA;AN+iBN;AM3iBQ;EACE,yBAAA;AN6iBV;;AMtiBA;EACE,yBAAA;EACA,mBAAA;EACA,aAAA;EACA,YAAA;EACA,SAAA;EACA,mBAAA;EACA,uBAAA;EACA,0BAAA;EACA,eAAA;ANyiBF;AMviBE;EACE,eAAA;EACA,iBAAA;EACA,+CJ9IY;EI+IZ,gBJzIG;EI0IH,yBAAA;EACA,cJtII;EIuIJ,kBAAA;ANyiBJ;AMviBI;EACE,WAAA;EACA,kBAAA;EACA,qEAAA;EACA,WAAA;EACA,YAAA;EACA,YAAA;EACA,SAAA;EACA,wBAAA;ANyiBN;;AMriBA;EACE,mBJ9IY;EI+IZ,mBAAA;EACA,kBAAA;EACA,aAAA;EACA,UAAA;EACA,sBAAA;EACA,QAAA;EACA,WAAA;ANwiBF;;AMriBA;EACE,kBAAA;EACA,YAAA;EACA,WAAA;EACA,4BAAA;EACA,UAAA;EACA,yFAAA;EACA,YAAA;EACA,OAAA;EACA,SAAA;EACA,UAAA;ANwiBF;;AMriBA;EACE,uBAAA;ANwiBF;AMviBE;EACE,SAAA;EACA,aAAA;EACA,mBAAA;EACA,uBAAA;EACA,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,+CJlMY;EImMZ,gBJ7LG;EI8LH,cJzLI;AFkuBR;AMviBE;EACE,WAAA;ANyiBJ;AMtiBE;EAEE,mBJ7LG;EI8LH,mBAAA;ANuiBJ;;AMniBA;EACE,yBAAA;EACA,mBAAA;EACA,aAAA;EACA,SAAA;EACA,mBAAA;EACA,uBAAA;EACA,0BAAA;EACA,eAAA;ANsiBF;AMriBE;EACE,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,+CJ9NY;EI+NZ,gBJzNG;EI0NH,cJrNI;EIsNJ,kBAAA;ANuiBJ;AMtiBI;EACE,WAAA;EACA,kBAAA;EACA,qEAAA;EACA,WAAA;EACA,YAAA;EACA,YAAA;EACA,SAAA;EACA,wBAAA;ANwiBN;;AMliBE;EACE,aAAA;EACA,iBAAA;EACA,kBAAA;ANqiBJ;AMjiBI;EACE,SAAA;EACA,wBAAA;EACA,wBAAA;EACA,kBAAA;ANmiBN;AMhiBI;EACE,gBAAA;ANkiBN;AMhiBQ;EACE,WAAA;EACA,uBAAA;EACA,eAAA;EACA,iBAAA;EACA,mDJvQU;EIwQV,gBJlQH;EImQG,0BAAA;EACA,qBAAA;EACA,kBAAA;ANkiBV;AMjiBU;EACE,WAAA;EACA,cAAA;EACA,kBAAA;EACA,UAAA;EACA,QAAA;EACA,2BAAA;EACA,WAAA;EACA,YAAA;ANmiBZ;AMhiBQ;EACE,qEAAA;ANkiBV;AMhiBQ;EACE,qEAAA;ANkiBV;AMhiBQ;EACE,qEAAA;ANkiBV;AM1hBE;EACE,aAAA;EACA,mBAAA;EACA,iBAAA;EACA,wBAAA;EACA,mBJvRU;AFmzBd;AM1hBE;EACE,eAAA;EACA,WAAA;EACA,iBAAA;AN4hBJ;AMthBE;EACE,kBAAA;ANwhBJ;AMthBE;EACE,iBAAA;EACA,eAAA;EACA,+CJ3TY;EI4TZ,gBJtTG;EIuTH,kBAAA;EACA,mBAAA;ANwhBJ;AMthBE;EACE,mBJpTE;EIqTF,wBAAA;EACA,aAAA;EACA,eAAA;ANwhBJ;;AMphBA;EACE,gBAAA;EACA,UAAA;EACA,QAAA;EACA,iBAAA;ANuhBF;;AMphBE;EACE,wBAAA;EACA,WAAA;EACA,YAAA;ANuhBJ;AMnhBA;EACE,yCAAA;ANqhBF;;AMnhBA;EACE,UAAA;EACA,mBAAA;EACA,SAAA;EACA,YAAA;ANshBF;;AOv4BA;EACE,aAAA;EACA,mBAAA;EACA,8BAAA;EACA,gBAAA;AP04BF;;AOx4BA;EACE,kBAAA;EACA,aAAA;EACA,YAAA;EACA,sBAAA;EACA,SAAA;EACA,mBL6BU;EK5BV,uBAAA;AP24BF;AO14BE;EACE,UAAA;EACA,WAAA;AP44BJ;;AOz4BA;EACE,gBAAA;EACA,WAAA;EACA,kBAAA;AP44BF;;AOz4BA;EACE,mBAAA;EACA,0BAAA;EACA,cLGM;EKFN,oDLRmB;EKSnB,gBLHM;EKIN,eAAA;EACA,iBAAA;AP44BF;;AOz4BA;EACE,aAAA;EACA,8BAAA;EACA,cAAA;EACA,oBAAA;AP44BF;;AOx4BE;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,+CL3BY;EK4BZ,gBLtBG;EKuBH,cLlBI;EKoBJ,oBAAA;EACA,mBAAA;EACA,yBAAA;KAAA,sBAAA;UAAA,iBAAA;EACA,eAAA;AP04BJ;;AOt4BA;EACE,WAAA;EACA,qBAAA;EACA,WAAA;EACA,YAAA;EACA,cAAA;EACA,YAAA;EACA,yBAAA;EACA,mBAAA;EACA,4BAAA;EACA,kCAAA;EACA,wBAAA;EACA,mBAAA;APy4BF;;AOt4BA;EACE,yBLzCI;EK0CJ,0DAAA;EACA,oBAAA;APy4BF;;AOv4BA;EACE,kBAAA;EACA,WAAA;AP04BF;AOz4BE;EACE,eAAA;EACA,iBAAA;EACA,+CLhEY;EKiEZ,gBL3DG;EK4DH,cLvDI;EKwDJ,eAAA;AP24BJ;AOz4BI;EACE,WAAA;EACA,kBAAA;EACA,WAAA;EACA,YAAA;EACA,QAAA;EACA,qEAAA;EACA,yBAAA;EACA,WAAA;EACA,uBAAA;AP24BN;;AOt4BA;EACE,yBAAA;EACA,mBAAA;EACA,aAAA;EACA,mBAAA;EACA,2BAAA;EACA,4BAAA;APy4BF;AOt4BI;EACE,MAAA;EACA,cAAA;EACA,UAAA;EACA,iBAAA;APw4BN;AOp4BQ;EACE,wBAAA;APs4BV;;AOh4BA;EACE,mBAAA;EACA,mBAAA;APm4BF;;AO73BI;EAEI,aAAA;AP+3BR;;AO13BE;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EAEA,cAAA;EACA,mDLjIgB;EKkIhB,gBL5HG;AFw/BP;;AOx3BA;EAGE,qBAAA;AP63BF;;AOh4BA;EACE,kBAAA;EACA,SAAA;EAEA,WAAA;EACA,OAAA;AP23BF;;AOv3BE;EACE,aAAA;EACA,WAAA;AP03BJ;AOx3BE;EACE,aAAA;EACA,mBAAA;EACA,iBAAA;EACA,eAAA;AP03BJ;AOx3BI;EACE,cAAA;EACA,WAAA;EACA,YAAA;EACA,kBAAA;EACA,kBAAA;AP03BN;;AOn3BA;EACE,aAAA;EACA,mBAAA;EACA,8BAAA;EACA,QAAA;APs3BF;;AOn3BA;EACE,yBAAA;EACA,mBAAA;EACA,aAAA;EACA,mBAAA;EACA,kBAAA;EACA,QAAA;APs3BF;AOp3BE;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cAAA;EACA,mDLzLgB;EK0LhB,gBLpLG;AF0iCP;AOn3BE;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cAAA;EACA,mDLlMgB;EKmMhB,gBL7LG;EK8LH,UAAA;EACA,YAAA;EACA,YAAA;EACA,uBAAA;APq3BJ;AOp3BI;EAEE,YAAA;APq3BN;;AOh3BA;EACE,WAAA;EACA,WAAA;EACA,mBLpMI;AFujCN;;AQxlCA;EACE,aAAA;EACA,oBAAA;EACA,SAAA;AR2lCF;;AQzlCA;EACE,mBAAA;AR4lCF;;AQ1lCA;EACE,gBAAA;AR6lCF;;AQ3lCA;EACE,aAAA;EACA,qCAAA;EACA,cAAA;EACA,mBAAA;EACA,gBAAA;EACA,2BAAA;AR8lCF;AQ5lCE;EACE,qBAAA;EACA,gCAAA;AR8lCJ;AQ3lCE;EACE,WAAA;AR6lCJ;AQ1lCE;EACE,mBAAA;EACA,mBNQK;AFolCT;AQzlCE;EACE,yBNGK;EMFL,mBAAA;EACA,yBAAA;AR2lCJ;;AQxlCA;EACE,eAAA;AR2lCF;;AQxlCA;EACE,gBAAA;EACA,WAAA;EACA,kBAAA;AR2lCF;AQ1lCE;EACE,YAAA;EACA,mBAAA;EACA,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cNtBI;EMuBJ,mDNnCgB;EMoChB,gBN9BG;AF0nCP;AQ3lCI;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cN7BE;EM8BF,mDN1Cc;EM2Cd,gBNrCC;AFkoCP;AQnmCI;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cN7BE;EM8BF,mDN1Cc;EM2Cd,gBNrCC;AFkoCP;AQ1lCE;EACE,WAAA;EACA,kBAAA;EACA,WAAA;EACA,YAAA;EACA,UAAA;EACA,6BAAA;EACA,qEAAA;AR4lCJ;;AQvlCE;EACE,mBAAA;EACA,iBAAA;EACA,oBAAA;KAAA,iBAAA;EACA,iBAAA;AR0lCJ;;AQvlCA;EACE,eAAA;EACA,gBAAA;AR0lCF;AQzlCE;EACE,gBAAA;EACA,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cAAA;EACA,mDN1EgB;EM2EhB,gBNrEG;AFgqCP;;AQvlCA;EACE,aAAA;AR0lCF;;AQvlCE;EACE,yBAAA;AR0lCJ;;AQtlCA;EACE,mBAAA;EACA,mBAAA;EACA,aAAA;EACA,mBAAA;EACA,uBAAA;EACA,eAAA;EACA,YAAA;EACA,kBAAA;EACA,WAAA;EACA,UAAA;ARylCF;AQxlCE;EACE,WAAA;EACA,YAAA;AR0lCJ;;AQtlCA;EACE,aAAA;EACA,sBAAA;EACA,kBAAA;ARylCF;;AQtlCA;EACE,kBAAA;EACA,UAAA;EACA,QAAA;EACA,eAAA;EACA,yBAAA;KAAA,sBAAA;UAAA,iBAAA;EACA,WAAA;EACA,sBAAA;EACA,yBAAA;EACA,iCAAA;EACA,eAAA;EACA,iBAAA;EACA,cN/GM;EMgHN,mBAAA;EACA,mBAAA;EACA,aAAA;EACA,mBAAA;EACA,SAAA;ARylCF;AQxlCE;EACE,WAAA;EACA,YAAA;AR0lCJ;;AQtlCA;EACE,kBAAA;EACA,UAAA;EACA,qBAAA;EACA,iBAAA;EACA,iBAAA;EACA,UAAA;EACA,gBAAA;EACA,mBAAA;EACA,mBAAA;EACA,oBAAA;EACA,QAAA;EACA,oCAAA;EACA,aAAA;EACA,sBAAA;EACA,SAAA;EACA,UAAA;ARylCF;;AQtlCA;EACE,iBAAA;EACA,eAAA;EACA,yBAAA;KAAA,sBAAA;UAAA,iBAAA;EACA,mBAAA;EACA,6BAAA;ARylCF;AQxlCE;EACE,mBAAA;EACA,mBAAA;AR0lCJ;;AQtlCA;EACE,aAAA;ARylCF;;AQtlCA;EACE,eAAA;EACA,eAAA;EACA,aAAA;EACA,SAAA;EACA,mBAAA;ARylCF;AQxlCE;EACE,WAAA;EACA,YAAA;AR0lCJ;;AQtlCA;EACE,UAAA;EACA,gBAAA;EACA,mBAAA;ARylCF;;AQtlCA;EACE,aAAA;EACA,mBAAA;ARylCF;;AS1yCA;EACI,iBAAA;EACA,cAAA;EACA,iBAAA;AT6yCJ;AS3yCI;EACI,aAAA;EACA,gDAAA;EACA,wBAAA;EACA,4CAAA;AT6yCR;AS1yCQ;EACI,cAAA;AT4yCZ;ASxyCI;EACI,eAAA;EACA,aAAA;EACA,kBAAA;EACA,yBPsBI;EOrBJ,wBAAA;AT0yCR;ASxyCI;EACI,SAAA;EACA,2BAAA;AT0yCR;;ASvyCA;EACI,aAAA;EACA,eAAA;EACA,mBAAA;AT0yCJ;ASxyCI;EACI,aAAA;EACA,eAAA;EACA,mBAAA;EACA,mBAAA;EACA,2BAAA;AT0yCR;ASxyCQ;EACI,uEAAA;AT0yCZ;ASxyCQ;EACE,eAAA;EACA,iBAAA;EACA,0BAAA;EACA,cPjBF;EOkBE,+CP7BM;EO8BN,gBPxBH;AFk0CP;ASxyCQ;EACE,WAAA;EACA,YAAA;EACA,kBAAA;AT0yCV;AStyCI;EACI,iBAAA;ATwyCR;;ASpyCA;EACI,eAAA;EACA,UAAA;EACA,mBAAA;EACA,YAAA;EACA,wBAAA;ATuyCJ;ASryCI;EACI,gBAAA;EACA,+CPrDQ;EOsDR,gBPhDD;EOiDC,eAAA;EACA,iBAAA;EACA,0BAAA;ATuyCR;ASpyCI;EACI,UAAA;EACA,kBAAA;EACA,SAAA;EACA,gBAAA;ATsyCR;;ASjyCI;EACI,gBAAA;EACA,aAAA;EACA,mBAAA;EACA,oBAAA;EACA,mBAAA;EACA,uCAAA;AToyCR;ASlyCI;EACI,gBAAA;EACA,mDPhFY;EOiFZ,gBP3ED;EO4EC,eAAA;EACA,iBAAA;AToyCR;ASnyCQ;EACI,+CPpFI;EOqFJ,gBP/EL;AFo3CP;ASlyCI;EACI,aAAA;EACA,UAAA;EACA,kBAAA;EACA,YAAA;EACA,wBAAA;EACA,SAAA;EACA,gBAAA;EACA,SAAA;AToyCR;ASnyCQ;EACI,UAAA;EACA,mBAAA;EACA,UAAA;EACA,YAAA;EACA,gBAAA;EACA,iBAAA;ATqyCZ;ASlyCI;EACI,aAAA;EACA,8BAAA;EACA,qBAAA;EACA,UAAA;EACA,kBAAA;EACA,YAAA;EACA,wBAAA;EACA,SAAA;EACA,iBAAA;EACA,SAAA;AToyCR;ASnyCQ;EACI,UAAA;EACA,mBAAA;EACA,UAAA;EACA,YAAA;EACA,gBAAA;ATqyCZ;ASlyCQ;EACI,iBAAA;EACA,kBAAA;EACA,WAAA;AToyCZ;ASlyCY;EACI,mDPpII;EOqIJ,gBP/HT;EOgIS,eAAA;EACA,iBAAA;EACA,cP1HV;EO2HU,kBAAA;EACA,qBAAA;EACA,UAAA;EACA,oBAAA;EACA,kBAAA;AToyChB;AShyCgB;EACI,UAAA;EACA,mBAAA;ATkyCpB;AShyCgB;EACI,2BAAA;ATkyCpB;AS7xCI;EACI,wBAAA;EACA,WAAA;EACA,YAAA;EACA,kBAAA;AT+xCR;AS7xCI;EACI,+CPjKQ;EOkKR,gBP5JD;EO6JC,oBAAA;EACA,iBAAA;EACA,0BAAA;AT+xCR;AS7xCI;EACI,yBPlJC;EOmJD,wBAAA;EACA,kBAAA;EACA,mBAAA;AT+xCR;AS7xCI;EACI,yBPxJC;EOyJD,wBAAA;EACA,kBAAA;AT+xCR;AS7xCI;EACI,kBAAA;EACA,kBAAA;EACA,yBPzKE;EO0KF,6BAAA;EACA,mBAAA;AT+xCR;AS7xCQ;EACI,yBAAA;AT+xCZ;AShyCQ;EACI,yBAAA;AT+xCZ;AS5xCQ;EACI,WAAA;EACA,cAAA;EACA,kBAAA;EACA,WAAA;EACA,YAAA;EACA,UAAA;EACA,QAAA;EACA,2BAAA;EACA,qEAAA;AT8xCZ;AS3xCI;EACI,qBAAA;EACA,WAAA;EACA,mDP7MY;EO8MZ,gBPxMD;EOyMC,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,6BAAA;EACA,mBAAA;EACA,aAAA;AT6xCR;AS3xCQ;EACI,yBAAA;AT6xCZ;AS3xCQ;EAII,+CAAA;EAOA,2CAAA;EACA,yBAAA;EACA,iCAAA;AT0xCZ;ASvyCQ;EAKI,yBAAA;EACA,UAAA;EACA,mDPhOQ;EOiOR,gBP3NL;EO4NK,eAAA;EACA,iBAAA;AT6xCZ;ASvxCI;EACI,mDP1OY;EO2OZ,gBPrOD;EOsOC,eAAA;EACA,iBAAA;EACA,gBAAA;EACA,gBAAA;ATyxCR;ASvxCI;EACI,+CPjPQ;EOkPR,gBP5OD;EO6OC,eAAA;EACA,iBAAA;EACA,yBAAA;EACA,aAAA;EACA,oBAAA;EACA,cP3OF;AFogDN;ASvxCQ;EACI,cP7OF;AFsgDV;;ASpxCI;EACI,qBAAA;EACA,mDPnQY;EOoQZ,gBP9PD;EO+PC,eAAA;EACA,iBAAA;ATuxCR;ASrxCI;EACI,eAAA;EACA,iBAAA;EACA,WAAA;EACA,YAAA;ATuxCR;;ASlxCI;EAEI,UAAA;EACA,mBAAA;EACA,wBAAA;AToxCR;ASlxCQ;EACI,gBAAA;EACA,QAAA;EACA,UAAA;EACA,kBAAA;EACA,SAAA;AToxCZ;AS/wCQ;EACI,gBAAA;EACA,+CPlSI;EOmSJ,gBP7RL;EO8RK,gBAAA;EACA,eAAA;EACA,iBAAA;EACA,mBAAA;ATixCZ;AS/wCQ;EACI,iBAAA;EACA,gBAAA;EACA,gBAAA;ATixCZ;AS/wCQ;EACI,uBAAA;EACA,mBAAA;EACA,yBAAA;EACA,aAAA;ATixCZ;AShxCY;EACI,mDPrTI;EOsTJ,gBPhTT;EOiTS,eAAA;EACA,iBAAA;EACA,cPzST;AF2jDP;AS7wCI;EACI,gBAAA;EACA,cAAA;EACA,2BAAA;AT+wCR;AS7wCQ;EACI,qBAAA;EACA,gCAAA;AT+wCZ;AS5wCQ;EACI,WAAA;AT8wCZ;AS3wCQ;EACI,mBP1TH;EO2TG,mBAAA;AT6wCZ;AS1wCQ;EACI,yBPhUH;EOiUG,mBAAA;EACA,yBAAA;AT4wCZ;ASzwCQ;EACI,iBAAA;EACA,cAAA;AT2wCZ;AS1wCY;EACI,WAAA;AT4wChB;AS1wCY;EACI,aAAA;EACA,eAAA;AT4wChB;AS1wCY;EACI,gCAAA;AT4wChB;AS1wCY;EACI,aAAA;EACA,mBAAA;EACA,uBAAA;EACA,UAAA;AT4wChB;AS1wCY;EACI,aAAA;EACA,mBAAA;AT4wChB;AS3wCgB;EACI,iBAAA;EACA,+CP9WJ;EO+WI,gBPzWb;EO0Wa,eAAA;EACA,iBAAA;EACA,yBAAA;AT6wCpB;AS1wCY;EACI,mDPvXI;EOwXJ,gBPlXT;EOmXS,eAAA;EACA,iBAAA;EACA,cAAA;AT4wChB;AS1wCY;EACI,kBAAA;EACA,kBAAA;AT4wChB;AS1wCgB;EACI,WAAA;EACA,kBAAA;EACA,cAAA;EACA,OAAA;EACA,QAAA;EACA,2BAAA;EACA,WAAA;EACA,YAAA;EACA,kBAAA;AT4wCpB;ASzwCgB;EACI,yBPpXJ;AF+nDhB;ASzwCgB;EACI,yBPtXL;AFioDf;ASzwCgB;EACI,sBPxXN;AFmoDd;ASvwCQ;EACI,uBAAA;EACA,mBAAA;EACA,yBAAA;EACA,aAAA;ATywCZ;ASxwCY;EACI,mDP9ZI;EO+ZJ,gBPzZT;EO0ZS,eAAA;EACA,iBAAA;EACA,cPlZT;AF4pDP","sourcesContent":["//----- Библиотеки -----//\n@import \"../../node_modules/swiper/swiper-bundle.min.css\";\n@import \"../../node_modules/normalize.css\";\n\n//----- Глобальные стили -----//\n@import \"global/variables.scss\";\n@import \"global/global.scss\";\n@import \"global/mixins.scss\";\n@import \"global/fonts.scss\";\n@import \"global/basic.scss\";\n\n//----- Основные стили -----//\n@import \"blocks/pop-up.scss\";\n@import \"blocks/header.scss\";\n@import \"blocks/sidebar.scss\";\n@import \"blocks/test.scss\";\n@import \"blocks/profile.scss\";\n","*,\n*::before,\n*::after {\n  box-sizing: inherit;\n}\n.preload * {\n  transition: none !important;\n}\n\n\nhtml {\n  box-sizing: border-box;\n  min-height: 100vh;\n  // height: 100vh;\n}\n\nhtml,\nbody {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\nimg {\n  max-width: 100%;\n  height: auto;\n  display: block;\n}\n\nbutton {\n  border: none;\n  outline: none;\n  background: none;\n  cursor: pointer;\n}\n\na {\n  text-decoration: none;\n  font-family: $OpenSans;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 155%;\n  color: #999999;\n  margin: 0;\n  padding: 0;\n  cursor: pointer;\n  transition: 0.3s linear;\n}\n\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nli,\np,\nul {\n  padding: 0;\n  margin: 0;\n}\n\nh1 {\n  font-size: 64px;\n  line-height: 78px;\n  font-family: $OpenSans-Bold;\n  font-weight: $Bold;\n  color: $White;\n}\n\nh2 {\n  font-size: 30px;\n  line-height: 45px;\n  font-family: $OpenSans-Bold;\n  font-weight: $Bold;\n  color: $White;\n  margin-bottom: 21px;\n}\n\nul {\n  list-style-type: none;\n  padding: 0;\n  margin: 0;\n}\n\nbody {\n  min-width: 320px;\n  font-family: $OpenSans;\n  font-style: normal;\n  font-weight: 400;\n  color: $White;\n  font-size: 14px;\n  line-height: 17px;\n  background: $bg-body;\n\n  display: flex;\n  flex-direction: column;\n  margin: 0;\n  padding: 0;\n  // min-height: 100vh;\n  height: 100vh;\n  text-align: center;\n  @media (max-width: 767px) {\n    font-size: 12px;\n    line-height: 14px;\n  }\n}\n\nmain {\n  flex-grow: 1;\n  position: relative;\n  > div {\n    display: flex;\n    flex-direction: column;\n    margin: 0;\n    padding: 0;\n    min-height: 100vh;\n    text-align: center;\n  }\n}\n\n.visually-hidden {\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  margin: -1px;\n  padding: 0;\n  overflow: hidden;\n  white-space: nowrap;\n  border: 0;\n  clip: rect(0 0 0 0);\n  clip-path: inset(100%);\n}\n\n.container {\n  max-width: 100%;\n  margin: 0 auto;\n  padding: 0px 10px;\n}\n\ninput[type=\"radio\"],\ninput[type=\"checkbox\"] {\n  display: none;\n}\n\ninput {\n  background: rgba(248, 248, 248, 0.1);\n  border-radius: 10px;\n  padding: 18px 16px;\n  padding-right: 60px;\n  height: auto;\n  margin: 0;\n  width: 100%;\n  font-family: $OpenSans-SemiBold;\n  font-weight: $Normal;\n  font-size: 14px;\n  line-height: 17px;\n  outline: none;\n  color: $White;\n  border: 1px solid transparent;\n  position: relative;\n  &:focus {\n    border: 2px solid #df382d;\n  }\n}\n","// screen-resolution\n$container-max-width: 1200px;\n$desktop-width-middle: 1440px;\n$desktop-width: 1200px;\n$tablet-width: 1024px;\n$mobile-width: 767px;\n$mobile-width-middle: 480px;\n$mobile-width-min: 375px;\n\n//padding\n$desktop-padding: 0 30px;\n$tablet-padding: 0 15px;\n\n// retina\n$retina-dpi: 144dpi;\n$retina-dppx: 1.5dppx;\n\n//fonts\n$OpenSans: \"OpenSans-Regular\", arial, sans-serif;\n$OpenSans-SemiBold: \"OpenSans-SemiBold\", arial, sans-serif;\n$OpenSans-Bold: \"OpenSans-Bold\", arial, sans-serif;\n$OpenSans-ExtraBold: \"OpenSans-ExtraBold\", arial, sans-serif;\n\n//font-weight\n$Normal: 400;\n$Semi: 600;\n$Bold: 700;\n$Extra: 800;\n\n//colors\n$Black: #000000;\n$White: #ffffff;\n$bg-body: #151515;\n$red: #df382d;\n$crimson: #511511;\n$grey: #4c4c4c;\n$grey-1: #C9C9C9;\n$grey-2: #4A4A4A;\n$grey-3: #272424;\n$bg-all-lang: #2f2f2f;\n$bg-header: #1b1b1b;\n$bg-sidebar:#1b1b1b;\n$bg-info:#1b1b1b;\n$bg-history:#1b1b1b;\n$bg-pop-up:#1b1b1b;\n$status-yellow: #FFD43A;\n$status-green: #5BDF2D;\n$status-grey: #777;\n","@font-face {\n  font-family: \"OpenSans-Regular\";\n  src: url(\"../fonts/OpenSans-Regular.woff\") format(\"woff\"),\n    url(\"../fonts/OpenSans-Regular.woff2\") format(\"woff2\"),\n    url(\"../fonts/OpenSans-Regular.ttf\") format(\"truetype\");\n  font-weight: 400;\n  font-style: normal;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: \"OpenSans-SemiBold\";\n  src: url(\"../fonts/OpenSans-SemiBold.woff\") format(\"woff\"),\n    url(\"../fonts/OpenSans-SemiBold.woff2\") format(\"woff2\"),\n    url(\"../fonts/OpenSans-SemiBold.ttf\") format(\"truetype\");\n  font-weight: 600;\n  font-style: normal;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: \"OpenSans-Bold\";\n  src: url(\"../fonts/OpenSans-Bold.woff\") format(\"woff\"),\n    url(\"../fonts/OpenSans-Bold.woff2\") format(\"woff2\"),\n    url(\"../fonts/OpenSans-Bold.ttf\") format(\"truetype\");\n  font-weight: 700;\n  font-style: normal;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: \"OpenSans-ExtraBold\";\n  src: url(\"../fonts/OpenSans-ExtraBold.woff\") format(\"woff\"),\n    url(\"../fonts/OpenSans-ExtraBold.woff2\") format(\"woff2\"),\n    url(\"../fonts/OpenSans-ExtraBold.ttf\") format(\"truetype\");\n  font-weight: 800;\n  font-style: normal;\n  font-display: swap;\n}\n",".rub::after {\r\n    content: \"₽\";\r\n    display: inline-block;\r\n    padding-left: 6px;\r\n}\r\n.arrow{\r\n    position: relative;\r\n}\r\n.arrow::after {\r\n    content: \"\";\r\n    position: absolute;\r\n    background-image: url(\"../images/svg/arrow.svg\");\r\n    background-size: contain;\r\n    background-position: center;\r\n    background-repeat: no-repeat;\r\n    width: 25px;\r\n    height: 25px;\r\n    right: -5px;\r\n    top: 50%;\r\n    transform: translateY(-50%);\r\n    transition: 0.3s ease-in;\r\n}",".pop-up {\r\n    position: fixed;\r\n    top: 0;\r\n    bottom: 0;\r\n    left: 0;\r\n    right: 0;\r\n    height: 100vh;\r\n    width: 100vw;\r\n    z-index: 20;\r\n    background-color: rgba(#000, 0.6);\r\n\r\n    transition: opacity 500ms;\r\n    visibility: hidden;\r\n    opacity: 0;\r\n    overflow: hidden;\r\n\r\n    button{\r\n        transition: all 0.3s linear !important;\r\n    }\r\n\r\n    &:target{\r\n        visibility: visible;\r\n        opacity: 1;\r\n    }\r\n\r\n    &__inner{\r\n        max-width: 1042px;\r\n        width: 100%;\r\n        background: $bg-pop-up;\r\n        border-radius: 20px;\r\n        position: absolute;\r\n        top: 50%;\r\n        left: 50%;\r\n        transform: translate(-50%, -50%);\r\n        padding: 92px 99px 84px 95px;\r\n    }\r\n\r\n    &__cart {\r\n        display: flex;\r\n        justify-content: space-between;\r\n    }\r\n\r\n    &__btn-close{\r\n        position: absolute;\r\n        width: 17px;\r\n        height: 17px;\r\n        top: 26px;\r\n        right: 26px;\r\n        padding: 0;\r\n\r\n        &::before, &::after {\r\n            content: \"\";\r\n            display: block;\r\n            width: 20px;\r\n            height: 2px;\r\n            border-radius: 5px;\r\n            background-color: $grey-1;\r\n            position: absolute;\r\n\r\n        }\r\n        &::before {\r\n            z-index: 11;\r\n            top: 8px;\r\n            left: -2px;\r\n            transform: rotate(-45deg);\r\n        }\r\n        &::after {\r\n            z-index: 12;\r\n            top: 8px;\r\n            left: -2px;\r\n            transform: rotate(45deg);\r\n        }\r\n    }\r\n    &__title {\r\n        font-family: $OpenSans-Bold;\r\n        font-weight: $Bold;    \r\n        font-size: 44.2512px;\r\n        line-height: 60px;\r\n        text-transform: uppercase;\r\n        margin-bottom: 61px;\r\n    }\r\n    &__auth-form {\r\n\r\n    }\r\n\r\n}\r\n.pop-up-cart {\r\n    &__img {\r\n        margin-right: 44px;\r\n        width: 335px;\r\n        height: 335px;\r\n        border-radius: 20px;\r\n\r\n        img{\r\n            object-fit: cover;\r\n            max-width: none;\r\n        }\r\n    }\r\n    &__content {\r\n        width: 100%;\r\n        text-align: left;\r\n    }\r\n    &__title {\r\n        font-family: $OpenSans-Bold;\r\n        font-weight: $Bold;    \r\n        font-size: 36px;\r\n        line-height: 49px;\r\n        text-transform: capitalize;\r\n        margin-bottom: 32px;\r\n    }\r\n    &__info {}\r\n    &__info-item {}\r\n    &__form {\r\n        .cart-info-item {\r\n            align-items: center;\r\n        }\r\n        &-label {\r\n\r\n        }\r\n        &-number{\r\n            width: 68px;\r\n            display: flex;\r\n\r\n            input{\r\n                padding: 0;\r\n                background: none;\r\n\r\n                &:focus{\r\n                    border: none;\r\n                }    \r\n            }\r\n        }\r\n        &-input {\r\n            -moz-appearance: textfield;\r\n            -webkit-appearance: textfield;\r\n            appearance: textfield;\r\n            background-color: transparent;\r\n            width: 44px;\r\n            padding: 0;\r\n            text-align: center;\r\n            font-family: $OpenSans-SemiBold;\r\n            font-weight: $Semi;\r\n            font-size: 17.8495px;\r\n            line-height: 24px;\r\n            text-transform: capitalize;\r\n            color: #FFF5F5;\r\n            \r\n            text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25), 0px 4px 4px rgba(0, 0, 0, 0.25);\r\n            \r\n\r\n            &::-webkit-outer-spin-button,\r\n            &::-webkit-inner-spin-button {\r\n                display: none;\r\n            }\r\n        }\r\n        &-total {\r\n            font-family: $OpenSans-Bold;\r\n            font-weight: $Bold;    \r\n            font-size: 40.1613px;\r\n            line-height: 55px;\r\n            text-transform: capitalize;\r\n            margin-top: 28px;\r\n            margin-bottom: 18px;\r\n        }    \r\n        &-btn {\r\n            display: flex;\r\n            align-items: center;\r\n            width: 100%;\r\n            justify-content: center;\r\n            padding-top: 18px;\r\n            padding-bottom: 16px;\r\n            background: linear-gradient(100.85deg, #DF382D 18.11%, #CF0200 105.96%);\r\n            border: 3.34677px solid #DF382D;\r\n            border-radius: 8px;\r\n            img {\r\n                margin-right: 14px;\r\n            }\r\n            p{\r\n                font-family: $OpenSans-Bold;\r\n                font-weight: $Bold;    \r\n                font-size: 24px;\r\n                line-height: 33px;\r\n                text-transform: uppercase;\r\n                color: $White;\r\n            }\r\n\r\n            &-grey {\r\n                margin-top: 16px;\r\n                display: flex;\r\n                justify-content: center;\r\n                padding-top: 20px;\r\n                padding-bottom: 19px;\r\n                background: transparent;\r\n                border: 3.34677px solid #DF382D;\r\n                border-radius: 8px;\r\n                img {\r\n                    margin-right: 14px;\r\n                }\r\n                p{\r\n                    font-family: $OpenSans-Bold;\r\n                    font-weight: $Bold;    \r\n                    font-size: 24px;\r\n                    line-height: 33px;\r\n                    text-transform: uppercase;\r\n                    color: $White;\r\n                }\r\n            }\r\n        }    \r\n        &-empty-balance{\r\n            display: none;\r\n        }\r\n        &-replenished-balance{\r\n            display: none;\r\n        }\r\n    }\r\n}\r\n.cart-info-item {\r\n    background-color: $bg-body;\r\n    border-radius: 5.57796px;\r\n    padding: 10px 37px 8px 32px;\r\n    margin-bottom: 7.5px;\r\n    display: flex;\r\n    justify-content: space-between;\r\n\r\n    span {\r\n        display: inline-block;\r\n    }\r\n\r\n    &__label {\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        text-transform: capitalize;\r\n        color: $grey-1;\r\n    }\r\n    &__value {\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        text-transform: capitalize;\r\n    }\r\n}\r\n\r\n.pop-up-auth {\r\n    &__field {\r\n        margin-bottom: 45px;\r\n        text-align: right;\r\n        & > div {\r\n            padding: 12px 10px 12px 25px;\r\n            display: flex;\r\n            border-bottom: 2px solid $red;    \r\n            img {\r\n                margin-right: 25px;\r\n            }    \r\n        }\r\n        small {\r\n            display: inline-block;\r\n            padding-top: 8px;\r\n            padding-right: 13px;\r\n            font-family: $OpenSans-SemiBold;\r\n            font-weight: $Semi;\r\n            font-size: 14px;\r\n            line-height: 19px;\r\n            color: $red;\r\n            opacity: 0;\r\n            transition: all .3s;\r\n            visibility: hidden;\r\n        }\r\n        .error {\r\n            width: 0;\r\n            height: 18px;\r\n            position: relative;\r\n            transition: opacity .3s ease-in, width .3s ease-in, visibility .3s ease-in;\r\n            opacity: 0;\r\n            visibility: hidden;\r\n            &::before, &::after {\r\n                content: \"\";\r\n                display: block;\r\n                width: 22px;\r\n                height: 4px;\r\n                border-radius: 5px;\r\n                background-color: $red;\r\n                position: absolute;\r\n            }    \r\n            &::before {\r\n                top: 8px;\r\n                left: -2px;\r\n                transform: rotate(-45deg);\r\n            }\r\n            &::after {\r\n                top: 8px;\r\n                left: -2px;\r\n                transform: rotate(45deg);\r\n            }\r\n\r\n        }\r\n        &.invalid{\r\n            .error {\r\n                    width: 18px;\r\n                    opacity: 1;\r\n                    visibility: visible;\r\n                }\r\n            & > small{\r\n                opacity: 1;\r\n                visibility: visible;\r\n            }\r\n    \r\n        }\r\n\r\n    }\r\n    &__input  {\r\n        padding: 0 10px;\r\n        background-color: transparent !important;\r\n        border-radius: 20px;\r\n        border: none;\r\n        &:focus{\r\n            border: none;\r\n            outline: none;\r\n        }\r\n        &:-webkit-autofill,\r\n        &:-webkit-autofill:hover,\r\n        &:-webkit-autofill:focus,\r\n        &:-webkit-autofill:active  {\r\n            box-shadow: 0 0 0 40px $bg-pop-up inset !important;\r\n            border: 1px solid $bg-body;\r\n            outline: 0;\r\n            font-family: $OpenSans-SemiBold;\r\n            font-weight: $Semi;\r\n            font-size: 17.7005px;\r\n            line-height: 24px;\r\n            -webkit-text-fill-color: $White !important;\r\n            color: $White !important;    \r\n            background-image: none !important;\r\n        }\r\n    }\r\n    &__input, &__input::placeholder {\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 17.7005px;\r\n        line-height: 24px;\r\n        color: $White;\r\n    }\r\n    &__buttons-login {\r\n        .pop-up-cart__form-btn{\r\n            img{\r\n                margin-right: 0;\r\n                margin-left: 14px;\r\n            }\r\n        }\r\n    }\r\n    &__services {\r\n        margin-top: 52px;\r\n        display: flex;\r\n        justify-content: center;\r\n    }\r\n    &__service-btn {\r\n        cursor: pointer;\r\n        &+&{\r\n            margin-left: 15px;\r\n        }\r\n    }\r\n    &__checkbox {\r\n        text-align: left;\r\n        margin: 44px 0;\r\n        input {\r\n\r\n        }\r\n        label {\r\n            display: inline-flex;\r\n            align-items: center;\r\n            font-family: $OpenSans-SemiBold;\r\n            font-weight: $Semi;\r\n            font-size: 16px;\r\n            line-height: 31px;\r\n\r\n            &::before {\r\n                margin-right: 18px !important;\r\n            }\r\n            a {\r\n                color: $red;\r\n            }\r\n        }\r\n    }\r\n}\r\n.username {\r\n}\r\n.password {\r\n    .btn-visibility{\r\n        margin-left: 7px;\r\n        cursor: pointer;\r\n        width: 35px;\r\n        background: url(\"../images/svg/hidden-grey.svg\") center no-repeat;\r\n        transition: all .3s ease-in;\r\n        &.visible{\r\n            background: url(\"../images/svg/visible-grey.svg\") center no-repeat;\r\n        }\r\n    }\r\n}\r\n.pop-up-cart {\r\n    &__form-btn {}\r\n    &__form-btn-grey {}\r\n}\r\n",".logo {\n  max-width: 314px;\n  width: 100%;\n  margin-right: auto;\n  img {\n    width: 100%;\n  }\n}\n.header {\n  background-color: $bg-header;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.header__wrapper {\n  display: flex;\n  gap: 39px;\n  align-items: center;\n  justify-content: space-between;\n}\n.header__btns {\n  display: flex;\n  gap: 19px;\n  align-items: center;\n}\n.header__list {\n  display: flex;\n  gap: 100px;\n  align-items: center;\n}\n\n.header__logIn {\n  display: flex;\n  cursor: pointer;\n  justify-content: center;\n  align-items: center;\n  max-width: 331px;\n  width: 100%;\n  gap: 11px;\n  background: linear-gradient(100.85deg, #df382d 18.11%, #9f0200 105.95%);\n  border-radius: 10px;\n  padding: 21.5px;\n  margin-left: auto;\n  p {\n    font-size: 26px;\n    line-height: 35px;\n    text-transform: uppercase;\n    color: $White;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n  }\n  img {\n    width: auto;\n  }\n}\n\n.header-list__item {\n  a {\n    font-size: 18px;\n    text-transform: uppercase;\n    line-height: 25px;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    color: $White;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n  }\n}\n\n.link_shop,\n.link_show,\n.link_inventory,\n.link_help {\n  a {\n    position: relative;\n    &::before {\n      content: \"\";\n      position: absolute;\n      left: -28px;\n\n      width: 20px;\n      height: 20px;\n    }\n  }\n}\n\n.link_shop {\n  background: $red;\n  border-radius: 10px;\n  padding: 18px;\n  width: 180px;\n  a {\n    padding-left: 20px;\n    &::before {\n      left: 10px;\n      background: url(\"../images/svg/shop.svg\") center no-repeat;\n    }\n  }\n}\n\n.link_help {\n  a {\n    &::before {\n      background: url(\"../images/svg/vopros.svg\") center no-repeat;\n    }\n  }\n}\n\n.link_show {\n  a {\n    &::before {\n      background: url(\"../images/svg/eye.svg\") center no-repeat;\n    }\n  }\n}\n\n.link_inventory {\n  a {\n    &::before {\n      background: url(\"../images/svg/app.svg\") center no-repeat;\n    }\n  }\n}\n\n\n.dropDown {\n  position: relative;\n  height: 60px;\n  &:hover,\n  &:focus {\n    .hide__items {\n      padding-top: 10px;\n      opacity: 1;\n      transform: translateY(0);\n      transition-delay: 0.15s;\n      top: 100%;\n    }\n    .header-languages__current, .header-currency__current {\n      p {\n        &::before {\n          transform: rotate(180deg);\n        }\n      }\n    }\n  }\n}\n\n.header-languages__current {\n  border: 2px solid $red;\n  border-radius: 10px;\n  display: flex;\n  height: 100%;\n  gap: 10px;\n  align-items: center;\n  justify-content: center;\n  padding: 7px 44px 7px 19px;\n  cursor: pointer;\n\n  p {\n    font-size: 20px;\n    line-height: 27px;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    text-transform: uppercase;\n    color: $White;\n    position: relative;\n\n    &::before {\n      content: \"\";\n      position: absolute;\n      background: url(\"../images/svg/arrow.svg\") center no-repeat;\n      width: 25px;\n      height: 25px;\n      right: calc(-100%);\n      bottom: 0;\n      transition: 0.3s ease-in;\n    }\n  }\n}\n.hide-items__wrapper {\n  background: $bg-all-lang;\n  border-radius: 10px;\n  padding: 16px 10px;\n  display: flex;\n  z-index: 1;\n  flex-direction: column;\n  gap: 8px;\n  width: 100%;\n}\n\n.hide__items {\n  position: absolute;\n  z-index: 100;\n  width: 100%;\n  transform: translateY(-30px);\n  opacity: 0;\n  transition: transform 0.5s linear 0.1s, opacity 0.1s linear 0.1s, height 0.1s linear 0.1s;\n  top: -9999px;\n  left: 0;\n  height: 0;\n  padding: 0;\n}\n\n.hide__item {\n  transition: 0.3s linear;\n  a {\n    gap: 10px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    font-size: 18px;\n    line-height: 25px;\n    text-transform: uppercase;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    color: $White;\n  }\n  img {\n    width: 40px;\n  }\n\n  &:hover,\n  &:focus {\n    background: $grey;\n    border-radius: 10px;\n  }\n}\n\n.header__currency {\n  border: 2px solid $red;\n  border-radius: 10px;\n  display: flex;\n  gap: 10px;\n  align-items: center;\n  justify-content: center;\n  padding: 7px 44px 7px 19px;\n  cursor: pointer;\n  p {\n    font-size: 20px;\n    line-height: 27px;\n    text-transform: uppercase;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    color: $White;\n    position: relative;\n    &::before {\n      content: \"\";\n      position: absolute;\n      background: url(\"../images/svg/arrow.svg\") center no-repeat;\n      width: 25px;\n      height: 25px;\n      right: -25px;\n      bottom: 0;\n      transition: 0.3s ease-in;\n    }\n  }\n}\n\n.header {\n  &__info-user{\n    display: flex;\n    margin-left: 94px;\n    position: relative;\n    // transition: 0.3s ease-in;\n    // transition-delay: 0.15s;\n\n    .hide__items {\n      top: 100%;\n      transform: translateY(0);\n      transition: opacity .5s;\n      visibility: hidden;\n    }\n\n    .hide__item {\n      text-align: left;\n\n        a {\n          width: 100%;\n          padding: 9px 0 7px 48px;\n          font-size: 16px;\n          line-height: 22px;\n          font-family: $OpenSans-SemiBold;\n          font-weight: $Semi;\n          text-transform: capitalize;\n          display: inline-block;\n          position: relative;\n          &::before {\n            content: '';\n            display: block;\n            position: absolute;\n            left: 17px;\n            top: 50%;\n            transform: translateY(-50%);\n            width: 21px;\n            height: 21px;\n          }\n        }\n        &:nth-child(1) a::before {\n          background: url(\"../images/svg/credit-card-red.svg\") center no-repeat;\n        }\n        &:nth-child(2) a::before {\n          background: url(\"../images/svg/profile-icon.svg\") center no-repeat;\n        }\n        &:nth-child(3) a::before {\n          background: url(\"../images/svg/log-out.svg\") center no-repeat;\n        }\n\n\n    }\n\n    \n  }\n  &__bill {\n    display: flex;\n    align-items: center;\n    padding: 8px 14px;\n    border-radius: 8.44291px;\n    background: $bg-all-lang;\n  }\n  &__profile {\n    cursor: pointer;\n    width: 84px;\n    margin-left: 25px;\n  }\n  &__profile-wrapper {}\n}\n.header-bill {\n  \n  &__img {\n    margin-right: 14px;\n  }\n  &__value {\n    line-height: 24px;\n    font-size: 18px;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    margin-right: 14px;\n    white-space: nowrap;\n  }\n  &__btn {\n    background: $red;\n    border-radius: 8.44291px;\n    padding: 14px;\n    cursor: pointer;\n\n  }\n}\n.header-info-user__options{\n  max-width: 175px;\n  left: auto;\n  right: 0;\n  padding-top: 14px;\n}\n.header-profile {\n  &__img {\n    border-radius: 8.44291px;\n    width: 60px;\n    height: 60px;\n  }\n  &__options {}\n}\n[drop-down-btn].active > .arrow::after {\n  transform: rotate(180deg) translateY(50%);\n}\n[drop-down-content].active {\n  opacity: 1;\n  visibility: visible;\n  top: 100%;\n  height: auto;\n}\n\n.options-all {\n  &__wrapper {}\n  &__item {}\n}\n\n",".sidebar__socials {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: auto;\n}\n.sidebar__wrapper {\n  padding: 21px 32px;\n  display: flex;\n  height: 100%;\n  flex-direction: column;\n  gap: 31px;\n  background: $bg-sidebar;\n  align-items: flex-start;\n  > div {\n    z-index: 2;\n    width: 100%;\n  }\n}\n.sidebar {\n  max-width: 357px;\n  width: 100%;\n  position: relative;\n}\n\n.sidebar-item__title {\n  margin-bottom: 19px;\n  text-transform: capitalize;\n  color: $White;\n  font-family: $OpenSans-ExtraBold;\n  font-weight: $Extra;\n  font-size: 26px;\n  line-height: 35px;\n}\n\n.sidebar-types__area {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  grid-gap: 31px;\n  justify-items: start;\n}\n\n.sidebar-types__item {\n  label {\n    font-size: 20px;\n    line-height: 27px;\n    text-transform: capitalize;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    color: $White;\n\n    display: inline-flex;\n    align-items: center;\n    user-select: none;\n    cursor: pointer;\n  }\n}\n\n.custom-check + label::before {\n  content: \"\";\n  display: inline-block;\n  width: 31px;\n  height: 31px;\n  flex-shrink: 0;\n  flex-grow: 0;\n  border: 2px solid $red;\n  margin-right: 0.5em;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: 50% 50%;\n  border-radius: 10px;\n}\n\n.custom-check:checked + label::before {\n  background-color: $red;\n  background-image: url(\"../images/svg/check.svg\");\n  background-size: 80%;\n}\n.sidebar-rarities_current {\n  position: relative;\n  width: 100%;\n  p {\n    font-size: 20px;\n    line-height: 27px;\n    font-family: $OpenSans-Bold;\n    font-weight: $Bold;\n    color: $White;\n    cursor: pointer;\n\n    &::after {\n      content: \"\";\n      position: absolute;\n      width: 15px;\n      height: 15px;\n      right: 0;\n      background: url(\"../images/svg/arrow.svg\") center no-repeat;\n      transform: rotate(270deg);\n      bottom: 5px;\n      transition: 0.3s linear;\n    }\n  }\n}\n\n.sidebar-rarities {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n  padding: 17px 22px 16px 27px;\n  &:hover,\n  &:focus {\n    .hide__items {\n      top: 0;\n      padding-top: 0;\n      left: 100%;\n      padding-left: 6px;\n    }\n    .sidebar-rarities_current {\n      p {\n        &::after {\n          transform: rotate(90deg);\n        }\n      }\n    }\n  }\n}\n.sidebar-rarities__item.checked {\n  background: #4c4c4c;\n  border-radius: 10px;\n}\n\n\n.sidebar-currency__item {\n  input {\n    &::-webkit-outer-spin-button,\n    &::-webkit-inner-spin-button {\n        display: none;\n    }\n  }\n  }\n.sidebar-rarities__item {\n  label {\n    font-size: 18px;\n    line-height: 25px;\n    text-transform: capitalize;\n\n    color: #c9c9c9;\n    font-family: $OpenSans-SemiBold;\n    font-weight: $Semi;\n  }\n}\n\n.sidebar__img {\n  position: absolute;\n  bottom: 0;\n  z-index: 1 !important;\n  width: 100%;\n  left: 0;\n}\n\n.sidebar-rarities{\n  &.dropDown{\n    display: flex;\n    width: 100%;\n  }\n  &__item {\n    display: flex;\n    align-items: center;\n    padding: 9px 26px;\n    cursor: pointer\n    ;\n    .dot {\n      display: block;\n      width: 17px;\n      height: 17px;\n      margin-right: 17px;\n      border-radius: 4px;\n    }\n  }\n  \n}\n\n\n.sidebar-currency__wrapper {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 7px;\n}\n\n.sidebar-currency__item {\n  border: 2px solid #df382d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  padding: 10px 13px;\n  gap: 9px;\n\n  label {\n    font-size: 20px;\n    line-height: 27px;\n    text-transform: capitalize;\n    color: #ffffff;\n    font-family: $OpenSans-SemiBold;\n    font-weight: $Semi;\n  }\n\n  input {\n    font-size: 20px;\n    line-height: 27px;\n    text-transform: capitalize;\n    color: #ffffff;\n    font-family: $OpenSans-SemiBold;\n    font-weight: $Semi;\n    padding: 0;\n    border: none;\n    height: 27px;\n    background: transparent;\n    &:focus,\n    &:hover {\n      border: none;\n    }\n  }\n}\n\n.sidebar-currency__rasdel {\n  width: 10px;\n  height: 2px;\n  background: $red;\n}\n",".page__wrapper {\n  display: flex;\n  align-items: stretch;\n  gap: 50px;\n}\n.pages__statusPanel {\n  margin-bottom: 50px;\n}\n.page__area {\n  margin-top: 50px;\n}\n.carts {\n  display: grid;\n  grid-template-columns: repeat(6, 1fr);\n  grid-gap: 46px;\n  padding-right: 41px;\n  overflow-y: auto;\n  height: calc(100vh - 294px);\n\n  & {\n    scrollbar-width: thin;\n    scrollbar-color: $grey-2 $grey-3;\n  }\n  \n  &::-webkit-scrollbar {\n    width: 19px;\n  }\n  \n  &::-webkit-scrollbar-track {\n    border-radius: 10px;\n    background: $grey-3;\n  }\n  \n  &::-webkit-scrollbar-thumb {\n    background-color: $grey-2;\n    border-radius: 20px;\n    border: 3px solid $grey-3;\n  }\n}\n.cart {\n  cursor: pointer;\n}\n\n.form-search {\n  max-width: 564px;\n  width: 100%;\n  position: relative;\n  input {\n    height: 65px;\n    padding: 19px 100px;\n    font-size: 20px;\n    line-height: 27px;\n    text-transform: capitalize;\n    color: $White;\n    font-family: $OpenSans-SemiBold;\n    font-weight: $Semi;\n    &::placeholder {\n      font-size: 20px;\n      line-height: 27px;\n      text-transform: capitalize;\n      color: $White;\n      font-family: $OpenSans-SemiBold;\n      font-weight: $Semi;\n    }\n  }\n  &::before {\n    content: \"\";\n    position: absolute;\n    width: 25px;\n    height: 26px;\n    left: 50px;\n    transform: translate(0%, 90%);\n    background: url(\"../images/svg/search.svg\") center no-repeat;\n  }\n}\n\n.cart__img {\n  img {\n    border-radius: 10px;\n    max-height: 197px;\n    object-fit: cover;\n    min-height: 197px;\n  }\n}\n.cart__content {\n  margin-top: 6px;\n  padding: 0px 9px;\n  p {\n    text-align: left;\n    font-size: 16px;\n    line-height: 22px;\n    text-transform: capitalize;\n    color: #ffffff;\n    font-family: $OpenSans-SemiBold;\n    font-weight: $Semi;\n  }\n}\n\n.form__selected-wrapper {\n  display: flex;\n}\n.form__selected-wrapper.active {\n  .form__selected-btn {\n    border: 2px solid #df382d;\n  }\n}\n\n.form__selected-btn {\n  background: #4d4d4d;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 65px;\n  height: 65px;\n  position: relative;\n  z-index: 10;\n  left: 19px;\n  img {\n    width: 38px;\n    height: 38px;\n  }\n}\n\n.form__select {\n  display: flex;\n  flex-direction: column;\n  position: relative;\n}\n\n.form__option-selected {\n  position: relative;\n  z-index: 1;\n  order: 0;\n  cursor: pointer;\n  user-select: none;\n  width: 100%;\n  padding: 0.7em 1.425em;\n  border: 1px solid #182f43;\n  transition: transform 0.1s linear;\n  font-size: 20px;\n  line-height: 27px;\n  color: $White;\n  background: #2f2f2f;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  gap: 11px;\n  img {\n    width: 24px;\n    height: 24px;\n  }\n}\n\n.form__options-container {\n  position: absolute;\n  z-index: 3;\n  top: calc(100% + 5px);\n  max-height: 273px;\n  padding: 16px 8px;\n  opacity: 0;\n  overflow: hidden;\n  background: #2f2f2f;\n  border-radius: 10px;\n  pointer-events: none;\n  order: 1;\n  transition: opacity 0.1s ease-in-out;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n  left: 19px;\n}\n\n.form__option {\n  padding: 5px 25px;\n  cursor: pointer;\n  user-select: none;\n  line-height: normal;\n  transition: color 0.1s linear;\n  &:hover {\n    background: #4c4c4c;\n    border-radius: 10px;\n  }\n}\n\n.form__option input {\n  display: none;\n}\n\n.form__option label {\n  cursor: pointer;\n  font-size: 14px;\n  display: flex;\n  gap: 11px;\n  align-items: center;\n  img {\n    width: 24px;\n    height: 24px;\n  }\n}\n\n.form__options-container.active {\n  opacity: 1;\n  overflow-y: auto;\n  pointer-events: all;\n}\n\n.pages__statusPanel {\n  display: flex;\n  align-items: center;\n}\n\n",".profile {\r\n    max-width: 1854px;\r\n    margin: 0 auto;\r\n    padding-top: 39px;\r\n\r\n    .page__wrapper{\r\n        display: grid;\r\n        grid-template-columns: auto minmax(auto, 1150px);\r\n        grid-auto-rows: auto 1fr;\r\n        grid-template-areas: \"tabs area\"\r\n                             \"info area\";\r\n\r\n        &.show-history{\r\n            display: block;\r\n        }\r\n    \r\n    }\r\n    .page__area{\r\n        grid-area: area;\r\n        margin-top: 0;\r\n        padding: 31px 42px;\r\n        background-color: $bg-history;\r\n        border-radius: 17.5728px;\r\n    }\r\n    .carts{\r\n        gap: 34px;\r\n        height: calc(100vh - 330px);\r\n    }\r\n}\r\n.profile__tabs{\r\n    display: flex;\r\n    grid-area: tabs;\r\n    margin-bottom: 47px;\r\n\r\n    .tab{\r\n        display: flex;\r\n        cursor: pointer;\r\n        align-items: center;\r\n        border-radius: 10px;\r\n        padding: 8px 25px 14px 28px;\r\n\r\n        &.active{\r\n            background: linear-gradient(100.85deg, #df382d 18.11%, #9f0200 105.95%);\r\n        }\r\n        p {\r\n          font-size: 24px;\r\n          line-height: 33px;\r\n          text-transform: capitalize;\r\n          color: $White;\r\n          font-family: $OpenSans-Bold;\r\n          font-weight: $Bold;\r\n        }\r\n        img {\r\n          width: 22px;\r\n          height: 30px;\r\n          margin-right: 14px;\r\n        }    \r\n\r\n    }\r\n    .tab + .tab {\r\n        margin-left: 40px;\r\n    }\r\n    \r\n}\r\n.profile__info{\r\n    grid-area: info;\r\n    opacity: 1;\r\n    visibility: visible;\r\n    height: auto;\r\n    transition: opacity .3s;\r\n\r\n    h3{\r\n        text-align: left;\r\n        font-family: $OpenSans-Bold;\r\n        font-weight: $Bold;\r\n        font-size: 30px;\r\n        line-height: 41px;\r\n        text-transform: capitalize;\r\n    }\r\n\r\n    &.hide {\r\n        opacity: 0;\r\n        visibility: hidden;\r\n        height: 0;\r\n        overflow: hidden;\r\n    }\r\n\r\n}\r\n.profile-info {\r\n    &__content {\r\n        margin-top: 30px;\r\n        display: flex;\r\n        align-items: center;\r\n        padding-bottom: 33px;\r\n        margin-bottom: 27px;\r\n        border-bottom: 0.878641px solid $grey;\r\n    }\r\n    &__large-items {\r\n        text-align: left;\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        span {\r\n            font-family: $OpenSans-Bold;\r\n            font-weight: $Bold;    \r\n        }\r\n    }\r\n    &__edit{\r\n        display: flex;\r\n        opacity: 0;\r\n        visibility: hidden;\r\n        z-index: -10;\r\n        transition: opacity .3s;\r\n        height: 0;\r\n        overflow: hidden;\r\n        margin: 0;\r\n        &.visible {\r\n            opacity: 1;\r\n            visibility: visible;\r\n            z-index: 1;    \r\n            height: auto;\r\n            margin-top: 49px;\r\n            overflow: visible;\r\n        }\r\n    }\r\n    &__form {\r\n        display: flex;\r\n        justify-content: space-between;\r\n        align-items: flex-end;\r\n        opacity: 0;\r\n        visibility: hidden;\r\n        z-index: -10;\r\n        transition: opacity .3s;\r\n        height: 0;\r\n        overflow: visible;\r\n        margin: 0;\r\n        &.visible {\r\n            opacity: 1;\r\n            visibility: visible;\r\n            z-index: 1;    \r\n            height: auto;\r\n            margin-top: 30px;\r\n        }\r\n\r\n        & > div {\r\n            text-align: right;\r\n            margin-right: 41px;\r\n            width: 100%;\r\n\r\n            & > small {\r\n                font-family: $OpenSans-SemiBold;\r\n                font-weight: $Semi;\r\n                font-size: 14px;\r\n                line-height: 19px;\r\n                color: $red;\r\n                margin-bottom: 7px;\r\n                display: inline-block;\r\n                opacity: 0;\r\n                transition: all .3s;\r\n                visibility: hidden;\r\n            }\r\n\r\n            &.invalid {\r\n                & > small{\r\n                    opacity: 1;\r\n                    visibility: visible;\r\n                }\r\n                & .profile-info__input-wrapper {\r\n                    border: 1.5px solid $red;\r\n                }\r\n            }\r\n        }\r\n    }\r\n    &__avatar{\r\n        border-radius: 8.44291px;\r\n        width: 70px;\r\n        height: 70px;    \r\n        margin-right: 24px;\r\n    }\r\n    &__username {\r\n        font-family: $OpenSans-Bold;\r\n        font-weight: $Bold;\r\n        font-size: 17.5728px;\r\n        line-height: 24px;\r\n        text-transform: capitalize;\r\n    }\r\n    &__personal {\r\n        background-color: $bg-info;\r\n        border-radius: 17.5728px;\r\n        padding: 40px 42px;\r\n        margin-bottom: 40px;\r\n    }\r\n    &__email {\r\n        background-color: $bg-info;\r\n        border-radius: 17.5728px;\r\n        padding: 40px 42px;\r\n    }\r\n    &__input-wrapper {\r\n        position: relative;\r\n        padding-left: 54px;\r\n        background-color: $bg-body;\r\n        border: 2px solid transparent;\r\n        border-radius: 10px;\r\n\r\n        &:focus-within{\r\n            border: 2px solid $red;\r\n        }\r\n\r\n        &::before{\r\n            content: \"\";\r\n            display: block;\r\n            position: absolute;\r\n            width: 22px;\r\n            height: 22px;\r\n            left: 17px;\r\n            top: 50%;\r\n            transform: translateY(-50%);\r\n            background: url(\"../images/svg/email-red.svg\") center no-repeat;\r\n        }\r\n    }\r\n    &__input {\r\n        display: inline-block;\r\n        width: 100%;\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        background-color: inherit;\r\n        border: 2px solid transparent;\r\n        border-radius: 20px;\r\n        padding: 10px;\r\n\r\n        &:focus{\r\n            border: 1px solid $bg-body;\r\n        }\r\n        &:-webkit-autofill,\r\n        &:-webkit-autofill:hover,\r\n        &:-webkit-autofill:focus,\r\n        &:-webkit-autofill:active  {\r\n            box-shadow: 0 0 0 40px $bg-body inset !important;\r\n            border: 1px solid $bg-body;\r\n            outline: 0;\r\n            font-family: $OpenSans-SemiBold;\r\n            font-weight: $Semi;\r\n            font-size: 18px;\r\n            line-height: 25px;\r\n            -webkit-text-fill-color: $White !important;\r\n            color: $White !important;    \r\n            background-image: none !important;\r\n        }\r\n    }\r\n    &__text {\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        margin-top: 53px;\r\n        text-align: left;\r\n    }\r\n    &__btn-edit-email{\r\n        font-family: $OpenSans-Bold;\r\n        font-weight: $Bold;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n        text-transform: uppercase;\r\n        padding: 19px;\r\n        transition: all .3s;\r\n        color: $red;\r\n\r\n        &[disabled] {\r\n            color: $crimson;\r\n        }\r\n    }\r\n}\r\n.profile-edit {\r\n    &__text {\r\n        display: inline-block;\r\n        font-family: $OpenSans-SemiBold;\r\n        font-weight: $Semi;\r\n        font-size: 18px;\r\n        line-height: 25px;\r\n    }\r\n    &__btn-change-email {\r\n        cursor: pointer;\r\n        margin-left: 15px;\r\n        width: 22px;\r\n        height: 22px;\r\n    }\r\n}\r\n.profile {\r\n\r\n    .page-area__wrapper{\r\n        // height: 100%;\r\n        opacity: 1;\r\n        visibility: visible;\r\n        transition: opacity .3s;\r\n    \r\n        &.hide {\r\n            overflow: hidden;\r\n            width: 0;\r\n            opacity: 0;\r\n            visibility: hidden;\r\n            height: 0;\r\n        }\r\n    \r\n    }\r\n    .history {\r\n        &__title{\r\n            text-align: left;\r\n            font-family: $OpenSans-Bold;\r\n            font-weight: $Bold;\r\n            font-weight: 700;\r\n            font-size: 30px;\r\n            line-height: 41px;\r\n            margin-bottom: 48px;\r\n        }\r\n        .cart__img img {\r\n            max-height: 140px;\r\n            min-height: auto;\r\n            min-width: 140px;\r\n        }\r\n        &__carts-empty{\r\n            justify-content: center;\r\n            align-items: center;\r\n            height: calc(100% - 89px);\r\n            display: none;\r\n            span {\r\n                font-family: $OpenSans-SemiBold;\r\n                font-weight: $Semi;\r\n                font-size: 20px;\r\n                line-height: 27px;\r\n                color: $grey;\r\n            }\r\n        }    \r\n    }\r\n\r\n    .replenishment{\r\n        overflow-y: auto;\r\n        display: block;\r\n        height: calc(100vh - 370px);\r\n\r\n        & {\r\n            scrollbar-width: thin;\r\n            scrollbar-color: $grey-2 $grey-3;\r\n        }\r\n        \r\n        &::-webkit-scrollbar {\r\n            width: 19px;\r\n        }\r\n        \r\n        &::-webkit-scrollbar-track {\r\n            background: $grey-3;\r\n            border-radius: 10px;\r\n        }\r\n        \r\n        &::-webkit-scrollbar-thumb {\r\n            background-color: $grey-2;\r\n            border-radius: 20px;\r\n            border: 3px solid $grey-3;\r\n        }        \r\n\r\n        &__table{\r\n            max-width: 1241px;\r\n            margin: 0 auto;\r\n            &, tbody{\r\n                width: 100%;\r\n            }\r\n            tr {\r\n                display: flex;\r\n                padding: 26px 0;\r\n            }\r\n            tr + tr {\r\n                border-bottom: 1px solid $grey;\r\n            }\r\n            td, th{\r\n                display: flex;\r\n                align-items: center;\r\n                justify-content: center;\r\n                width: calc(100% / 5);\r\n            }\r\n            tr:nth-child(1) > td {\r\n                display: flex;\r\n                align-items: center;\r\n                span{\r\n                    margin-left: 14px;\r\n                    font-family: $OpenSans-Bold;\r\n                    font-weight: $Bold;\r\n                    font-size: 24px;\r\n                    line-height: 33px;\r\n                    text-transform: uppercase;\r\n                }\r\n            }\r\n            tr:not(:first-child) > td {\r\n                font-family: $OpenSans-SemiBold;\r\n                font-weight: $Semi;\r\n                font-size: 20px;\r\n                line-height: 27px;\r\n                color: #FDFFFD;\r\n            }\r\n            .status{\r\n                padding-left: 30px;\r\n                position: relative;\r\n            \r\n                &::before {\r\n                    content: \"\";\r\n                    position: absolute;\r\n                    display: block;\r\n                    left: 0;\r\n                    top: 50%;\r\n                    transform: translateY(-50%);\r\n                    width: 11px;\r\n                    height: 11px;\r\n                    border-radius: 2px;\r\n\r\n                }\r\n                &.processing::before{\r\n                    background-color: $status-yellow;\r\n                }\r\n                &.translated::before{\r\n                    background-color: $status-green;\r\n                }\r\n                &.canceled::before{\r\n                    background-color: $status-grey;\r\n                }\r\n            }\r\n        }\r\n        &__empty {\r\n            justify-content: center;\r\n            align-items: center;\r\n            height: calc(100% - 87px);\r\n            display: none;\r\n            span {\r\n                font-family: $OpenSans-SemiBold;\r\n                font-weight: $Semi;\r\n                font-size: 20px;\r\n                line-height: 27px;\r\n                color: $grey;\r\n            }\r\n        }\r\n    }\r\n}\r\n\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/styles/style.scss":
/*!*******************************!*\
  !*** ./src/styles/style.scss ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_node_modules_sass_loader_dist_cjs_js_style_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!../../node_modules/sass-loader/dist/cjs.js!./style.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./node_modules/sass-loader/dist/cjs.js!./src/styles/style.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_node_modules_sass_loader_dist_cjs_js_style_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_node_modules_sass_loader_dist_cjs_js_style_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_node_modules_sass_loader_dist_cjs_js_style_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_node_modules_sass_loader_dist_cjs_js_style_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "data:application/font-woff;charset=utf-8;base64, d09GRgABAAAAAAZgABAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAGRAAAABoAAAAci6qHkUdERUYAAAWgAAAAIwAAACQAYABXR1BPUwAABhQAAAAuAAAANuAY7+xHU1VCAAAFxAAAAFAAAABm2fPczU9TLzIAAAHcAAAASgAAAGBP9V5RY21hcAAAAkQAAACIAAABYt6F0cBjdnQgAAACzAAAAAQAAAAEABEBRGdhc3AAAAWYAAAACAAAAAj//wADZ2x5ZgAAAywAAADMAAAD2MHtryVoZWFkAAABbAAAADAAAAA2E2+eoWhoZWEAAAGcAAAAHwAAACQC9gDzaG10eAAAAigAAAAZAAAArgJkABFsb2NhAAAC0AAAAFoAAABaFQAUGG1heHAAAAG8AAAAHwAAACAAcABAbmFtZQAAA/gAAAE5AAACXvFdBwlwb3N0AAAFNAAAAGIAAACE5s74hXjaY2BkYGAAYpf5Hu/j+W2+MnAzMYDAzaX6QjD6/4//Bxj5GA8AuRwMYGkAPywL13jaY2BkYGA88P8Agx4j+/8fQDYfA1AEBWgDAIB2BOoAeNpjYGRgYNBh4GdgYgABEMnIABJzYNADCQAACWgAsQB42mNgYfzCOIGBlYGB0YcxjYGBwR1Kf2WQZGhhYGBiYGVmgAFGBiQQkOaawtDAoMBQxXjg/wEGPcYDDA4wNUA2CCgwsAAAO4EL6gAAeNpj2M0gyAACqxgGNWBkZ2D4/wMA+xkDdgAAAHjaY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQrMOgyWDLEM1T9/w8UBfEMgLzE////P/5//f/V/xv+r4eaAAeMbAxwIUYmIMHEgKYAYjUcsDAwsLKxc3BycfPw8jEQA/gZBASFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTQZBgMAAMR+E+gAEQFEAAAAKgAqACoANAA+AEgAUgBcAGYAcAB6AIQAjgCYAKIArAC2AMAAygDUAN4A6ADyAPwBBgEQARoBJAEuATgBQgFMAVYBYAFqAXQBfgGIAZIBnAGmAbIBzgHsAAB42u2NMQ6CUAyGW568x9AneYYgm4MJbhKFaExIOAVX8ApewSt4Bic4AfeAid3VOBixDxfPYEza5O+Xfi04YADggiUIULCuEJK8VhO4bSvpdnktHI5QCYtdi2sl8ZnXaHlqUrNKzdKcT8cjlq+rwZSvIVczNiezsfnP/uznmfPFBNODM2K7MTQ45YEAZqGP81AmGGcF3iPqOop0r1SPTaTbVkfUe4HXj97wYE+yNwWYxwWu4v1ugWHgo3S1XdZEVqWM7ET0cfnLGxWfkgR42o2PvWrDMBSFj/IHLaF0zKjRgdiVMwScNRAoWUoH78Y2icB/yIY09An6AH2Bdu/UB+yxopYshQiEvnvu0dURgDt8QeC8PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/font-woff;charset=utf-8;base64, d09GRgABAAAAAAZgABAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAGRAAAABoAAAAci6qHkUdERUYAAAWgAAAAIwAAACQAYABXR1BPUwAABhQAAAAuAAAANuAY7+xHU1VCAAAFxAAAAFAAAABm2fPczU9TLzIAAAHcAAAASgAAAGBP9V5RY21hcAAAAkQAAACIAAABYt6F0cBjdnQgAAACzAAAAAQAAAAEABEBRGdhc3AAAAWYAAAACAAAAAj//wADZ2x5ZgAAAywAAADMAAAD2MHtryVoZWFkAAABbAAAADAAAAA2E2+eoWhoZWEAAAGcAAAAHwAAACQC9gDzaG10eAAAAigAAAAZAAAArgJkABFsb2NhAAAC0AAAAFoAAABaFQAUGG1heHAAAAG8AAAAHwAAACAAcABAbmFtZQAAA/gAAAE5AAACXvFdBwlwb3N0AAAFNAAAAGIAAACE5s74hXjaY2BkYGAAYpf5Hu/j+W2+MnAzMYDAzaX6QjD6/4//Bxj5GA8AuRwMYGkAPywL13jaY2BkYGA88P8Agx4j+/8fQDYfA1AEBWgDAIB2BOoAeNpjYGRgYNBh4GdgYgABEMnIABJzYNADCQAACWgAsQB42mNgYfzCOIGBlYGB0YcxjYGBwR1Kf2WQZGhhYGBiYGVmgAFGBiQQkOaawtDAoMBQxXjg/wEGPcYDDA4wNUA2CCgwsAAAO4EL6gAAeNpj2M0gyAACqxgGNWBkZ2D4/wMA+xkDdgAAAHjaY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQrMOgyWDLEM1T9/w8UBfEMgLzE////P/5//f/V/xv+r4eaAAeMbAxwIUYmIMHEgKYAYjUcsDAwsLKxc3BycfPw8jEQA/gZBASFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTQZBgMAAMR+E+gAEQFEAAAAKgAqACoANAA+AEgAUgBcAGYAcAB6AIQAjgCYAKIArAC2AMAAygDUAN4A6ADyAPwBBgEQARoBJAEuATgBQgFMAVYBYAFqAXQBfgGIAZIBnAGmAbIBzgHsAAB42u2NMQ6CUAyGW568x9AneYYgm4MJbhKFaExIOAVX8ApewSt4Bic4AfeAid3VOBixDxfPYEza5O+Xfi04YADggiUIULCuEJK8VhO4bSvpdnktHI5QCYtdi2sl8ZnXaHlqUrNKzdKcT8cjlq+rwZSvIVczNiezsfnP/uznmfPFBNODM2K7MTQ45YEAZqGP81AmGGcF3iPqOop0r1SPTaTbVkfUe4HXj97wYE+yNwWYxwWu4v1ugWHgo3S1XdZEVqWM7ET0cfnLGxWfkgR42o2PvWrDMBSFj/IHLaF0zKjRgdiVMwScNRAoWUoH78Y2icB/yIY09An6AH2Bdu/UB+yxopYshQiEvnvu0dURgDt8QeC8PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/font-woff;charset=utf-8;base64, d09GRgABAAAAAAZgABAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAGRAAAABoAAAAci6qHkUdERUYAAAWgAAAAIwAAACQAYABXR1BPUwAABhQAAAAuAAAANuAY7+xHU1VCAAAFxAAAAFAAAABm2fPczU9TLzIAAAHcAAAASgAAAGBP9V5RY21hcAAAAkQAAACIAAABYt6F0cBjdnQgAAACzAAAAAQAAAAEABEBRGdhc3AAAAWYAAAACAAAAAj//wADZ2x5ZgAAAywAAADMAAAD2MHtryVoZWFkAAABbAAAADAAAAA2E2+eoWhoZWEAAAGcAAAAHwAAACQC9gDzaG10eAAAAigAAAAZAAAArgJkABFsb2NhAAAC0AAAAFoAAABaFQAUGG1heHAAAAG8AAAAHwAAACAAcABAbmFtZQAAA/gAAAE5AAACXvFdBwlwb3N0AAAFNAAAAGIAAACE5s74hXjaY2BkYGAAYpf5Hu/j+W2+MnAzMYDAzaX6QjD6/4//Bxj5GA8AuRwMYGkAPywL13jaY2BkYGA88P8Agx4j+/8fQDYfA1AEBWgDAIB2BOoAeNpjYGRgYNBh4GdgYgABEMnIABJzYNADCQAACWgAsQB42mNgYfzCOIGBlYGB0YcxjYGBwR1Kf2WQZGhhYGBiYGVmgAFGBiQQkOaawtDAoMBQxXjg/wEGPcYDDA4wNUA2CCgwsAAAO4EL6gAAeNpj2M0gyAACqxgGNWBkZ2D4/wMA+xkDdgAAAHjaY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQrMOgyWDLEM1T9/w8UBfEMgLzE////P/5//f/V/xv+r4eaAAeMbAxwIUYmIMHEgKYAYjUcsDAwsLKxc3BycfPw8jEQA/gZBASFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTQZBgMAAMR+E+gAEQFEAAAAKgAqACoANAA+AEgAUgBcAGYAcAB6AIQAjgCYAKIArAC2AMAAygDUAN4A6ADyAPwBBgEQARoBJAEuATgBQgFMAVYBYAFqAXQBfgGIAZIBnAGmAbIBzgHsAAB42u2NMQ6CUAyGW568x9AneYYgm4MJbhKFaExIOAVX8ApewSt4Bic4AfeAid3VOBixDxfPYEza5O+Xfi04YADggiUIULCuEJK8VhO4bSvpdnktHI5QCYtdi2sl8ZnXaHlqUrNKzdKcT8cjlq+rwZSvIVczNiezsfnP/uznmfPFBNODM2K7MTQ45YEAZqGP81AmGGcF3iPqOop0r1SPTaTbVkfUe4HXj97wYE+yNwWYxwWu4v1ugWHgo3S1XdZEVqWM7ET0cfnLGxWfkgR42o2PvWrDMBSFj/IHLaF0zKjRgdiVMwScNRAoWUoH78Y2icB/yIY09An6AH2Bdu/UB+yxopYshQiEvnvu0dURgDt8QeC8PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA";

/***/ }),

/***/ "./src/fonts/OpenSans-Bold.ttf":
/*!*************************************!*\
  !*** ./src/fonts/OpenSans-Bold.ttf ***!
  \*************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Bold.ttf";

/***/ }),

/***/ "./src/fonts/OpenSans-Bold.woff":
/*!**************************************!*\
  !*** ./src/fonts/OpenSans-Bold.woff ***!
  \**************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Bold.woff";

/***/ }),

/***/ "./src/fonts/OpenSans-Bold.woff2":
/*!***************************************!*\
  !*** ./src/fonts/OpenSans-Bold.woff2 ***!
  \***************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Bold.woff2";

/***/ }),

/***/ "./src/fonts/OpenSans-ExtraBold.ttf":
/*!******************************************!*\
  !*** ./src/fonts/OpenSans-ExtraBold.ttf ***!
  \******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-ExtraBold.ttf";

/***/ }),

/***/ "./src/fonts/OpenSans-ExtraBold.woff":
/*!*******************************************!*\
  !*** ./src/fonts/OpenSans-ExtraBold.woff ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-ExtraBold.woff";

/***/ }),

/***/ "./src/fonts/OpenSans-ExtraBold.woff2":
/*!********************************************!*\
  !*** ./src/fonts/OpenSans-ExtraBold.woff2 ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-ExtraBold.woff2";

/***/ }),

/***/ "./src/fonts/OpenSans-Regular.ttf":
/*!****************************************!*\
  !*** ./src/fonts/OpenSans-Regular.ttf ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Regular.ttf";

/***/ }),

/***/ "./src/fonts/OpenSans-Regular.woff":
/*!*****************************************!*\
  !*** ./src/fonts/OpenSans-Regular.woff ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Regular.woff";

/***/ }),

/***/ "./src/fonts/OpenSans-Regular.woff2":
/*!******************************************!*\
  !*** ./src/fonts/OpenSans-Regular.woff2 ***!
  \******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-Regular.woff2";

/***/ }),

/***/ "./src/fonts/OpenSans-SemiBold.ttf":
/*!*****************************************!*\
  !*** ./src/fonts/OpenSans-SemiBold.ttf ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-SemiBold.ttf";

/***/ }),

/***/ "./src/fonts/OpenSans-SemiBold.woff":
/*!******************************************!*\
  !*** ./src/fonts/OpenSans-SemiBold.woff ***!
  \******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-SemiBold.woff";

/***/ }),

/***/ "./src/fonts/OpenSans-SemiBold.woff2":
/*!*******************************************!*\
  !*** ./src/fonts/OpenSans-SemiBold.woff2 ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/OpenSans-SemiBold.woff2";

/***/ }),

/***/ "./src/images/svg/app.svg":
/*!********************************!*\
  !*** ./src/images/svg/app.svg ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/app.svg";

/***/ }),

/***/ "./src/images/svg/arrow.svg":
/*!**********************************!*\
  !*** ./src/images/svg/arrow.svg ***!
  \**********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/arrow.svg";

/***/ }),

/***/ "./src/images/svg/check.svg":
/*!**********************************!*\
  !*** ./src/images/svg/check.svg ***!
  \**********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/check.svg";

/***/ }),

/***/ "./src/images/svg/credit-card-red.svg":
/*!********************************************!*\
  !*** ./src/images/svg/credit-card-red.svg ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/credit-card-red.svg";

/***/ }),

/***/ "./src/images/svg/email-red.svg":
/*!**************************************!*\
  !*** ./src/images/svg/email-red.svg ***!
  \**************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/email-red.svg";

/***/ }),

/***/ "./src/images/svg/eye.svg":
/*!********************************!*\
  !*** ./src/images/svg/eye.svg ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/eye.svg";

/***/ }),

/***/ "./src/images/svg/hidden-grey.svg":
/*!****************************************!*\
  !*** ./src/images/svg/hidden-grey.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/hidden-grey.svg";

/***/ }),

/***/ "./src/images/svg/log-out.svg":
/*!************************************!*\
  !*** ./src/images/svg/log-out.svg ***!
  \************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/log-out.svg";

/***/ }),

/***/ "./src/images/svg/profile-icon.svg":
/*!*****************************************!*\
  !*** ./src/images/svg/profile-icon.svg ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/profile-icon.svg";

/***/ }),

/***/ "./src/images/svg/search.svg":
/*!***********************************!*\
  !*** ./src/images/svg/search.svg ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/search.svg";

/***/ }),

/***/ "./src/images/svg/shop.svg":
/*!*********************************!*\
  !*** ./src/images/svg/shop.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/shop.svg";

/***/ }),

/***/ "./src/images/svg/visible-grey.svg":
/*!*****************************************!*\
  !*** ./src/images/svg/visible-grey.svg ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/visible-grey.svg";

/***/ }),

/***/ "./src/images/svg/vopros.svg":
/*!***********************************!*\
  !*** ./src/images/svg/vopros.svg ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/vopros.svg";

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		__webpack_require__.b = document.baseURI || self.location.href;
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"scripts": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkwebpack_template"] = self["webpackChunkwebpack_template"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_css-loader_dist_cjs_js_node_modules_normalize_css_normalize_css-node_mod-d796d8"], () => (__webpack_require__("./src/js/main.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=scripts.de982f64bfe2afccac90.js.map